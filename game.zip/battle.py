import random

from data import ALLskills, ALL_ITEMS
import characters as ch_module


def _get_globals():
    """Return the characters module so battle can read/write shared state."""
    return ch_module


class battle:
    def _on_player_death(self):
        """
        Общая обработка смерти игрока: предложить загрузить последнее сохранение,
        если есть глобальный объект game.
        """
        import game as game_module
        g = getattr(game_module, "game", None)
        if g is None:
            return
        load_method = getattr(g, "load_last_save_after_death", None)
        if callable(load_method):
            load_method()

    def _use_item_in_battle(self):
        """
        Меню использования предметов в бою.
        Возвращает (True, item_id), если предмет был успешно использован.
        """
        character = ch_module.character
        usable_items = [item for item in character.inventory if item in ALL_ITEMS]
        if not usable_items:
            print("У вас нет предметов, которые можно использовать в бою.")
            return False, None

        print("\n---Использование предмета---")
        for idx, item_id in enumerate(usable_items, start=1):
            data = ALL_ITEMS.get(item_id, {})
            name = data.get("name", item_id)
            print(f"{idx}. {name}")
        print("0. Назад")
        choice = input("Выберите предмет:").strip()
        try:
            idx = int(choice)
        except ValueError:
            print("Неверный ввод.")
            return False, None
        if idx == 0:
            return False, None
        if idx < 1 or idx > len(usable_items):
            print("Такого предмета нет.")
            return False, None

        item_id = usable_items[idx - 1]
        item = ALL_ITEMS.get(item_id, {})
        effect = item.get("effect")

        if effect == "heal":
            heal = item.get("heal_amount", 30)
            old_hp = character.hp
            character.hp = min(character.hp + heal, character.maxhp)
            print(f"Вы использовали {item.get('name', item_id)} и восстановили {character.hp - old_hp} HP.")
        elif effect == "mana":
            heal_sp = item.get("mana_amount", 15)
            old_sp = character.sp
            character.sp = min(character.sp + heal_sp, character.maxsp)
            print(f"Вы использовали {item.get('name', item_id)} и восстановили {character.sp - old_sp} SP.")
        elif effect == "stat":
            stat = item.get("stat")
            amount = item.get("amount", 1)
            if stat and stat in character.stats:
                character.stats[stat] += amount
                print(f"Ваша {stat} увеличилась на {amount}.")
            else:
                print("Этот предмет сейчас нельзя использовать.")
                return False, None
        elif effect == "gorgon":
            print("Вы поднимаете голову Медузы. Её мёртвый взгляд искажает пространство вокруг противника...")
        elif effect == "skill_stone":
            from data import SKILL_STONE_MAP, ALLskills
            skill_id = SKILL_STONE_MAP.get(item_id)
            if skill_id:
                added = character.add_skill(skill_id)
                if added:
                    print(f"*Камень рассыпается в свет... Умение «{ALLskills[skill_id]['name']}» изучено!*")
                else:
                    print(f"Это умение уже известно.")
                try:
                    character.inventory.remove(item_id)
                except ValueError:
                    pass
                return True, item_id
            else:
                print("Этот камень не распознан.")
                return False, None
        else:
            print("Этот предмет нельзя использовать в бою.")
            return False, None

        if effect != "gorgon":
            try:
                character.inventory.remove(item_id)
            except ValueError:
                pass

        return True, item_id

    # ------------------------------------------------------------------
    # тут короче вся боевая механика, расчёты урона, шанса попадания, крита и т.д.
    # ------------------------------------------------------------------
    def _calc_hit_chance(self, attacker_acc, defender_acc, base=0.8):
        chance = base + (attacker_acc - defender_acc) * 0.02
        return max(0.1, min(0.98, chance))

    def _calc_crit_chance(self, attacker_luck, defender_luck, base=0.05):
        chance = base + (attacker_luck - defender_luck) * 0.01
        return max(0.01, min(0.4, chance))

    def _apply_defense(self, damage, defender_def):
        return max(1, int(damage * (1 - defender_def * 0.02)))

    def _compute_player_damage(self, skill, enemy_obj):
        character = ch_module.character
        damage = skill.get("damage", 0)
        t = skill.get("type")
        if t == "Физический":
            weapon_bonus = character.get_weapon_damage_bonus()
            str_multiplier = 1 + character.get_effective_stat("СИЛ") / 10
            damage = int((damage + weapon_bonus) * str_multiplier)
        elif t == "Огонь":
            mag_multiplier = 1 + character.get_effective_stat("МАГ") / 10
            damage = int(damage * mag_multiplier * enemy_obj.IncFireDMG)
        elif t == "Лед":
            mag_multiplier = 1 + character.get_effective_stat("МАГ") / 10
            damage = int(damage * mag_multiplier * enemy_obj.IncIceDMG)
        elif t == "Электричество":
            mag_multiplier = 1 + character.get_effective_stat("МАГ") / 10
            damage = int(damage * mag_multiplier * enemy_obj.IncElecDMG)
        if skill.get("specialeffectuse") and skill.get("specialdamage"):
            damage = skill["specialdamage"]
        return damage

    def _compute_enemy_damage(self, skill, enemy_obj):
        character = ch_module.character
        damage = skill.get("damage", 0)
        t = skill.get("type")
        if t == "Физический":
            str_multiplier = 1 + enemy_obj.stats["СИЛ"] / 10
            damage = int(damage * str_multiplier)
        elif t == "Огонь":
            mag_multiplier = 1 + enemy_obj.stats["МАГ"] / 10
            damage = int(damage * mag_multiplier * character.IncFireDMG)
        elif t == "Лед":
            mag_multiplier = 1 + enemy_obj.stats["МАГ"] / 10
            damage = int(damage * mag_multiplier * character.IncIceDMG)
        elif t == "Электричество":
            mag_multiplier = 1 + enemy_obj.stats["МАГ"] / 10
            damage = int(damage * mag_multiplier * character.IncElecDMG)
        return damage

    def _is_weak_hit_on_enemy(self, skill, enemy_obj):
        t = skill.get("type")
        if t == "Огонь" and enemy_obj.IncFireDMG == 2:
            return True
        if t == "Лед" and enemy_obj.IncIceDMG == 2:
            return True
        if t == "Электричество" and enemy_obj.IncElecDMG == 2:
            return True
        return False

    def _is_weak_hit_on_player(self, skill):
        character = ch_module.character
        t = skill.get("type")
        if t == "Огонь" and character.IncFireDMG == 2:
            return True
        if t == "Лед" and character.IncIceDMG == 2:
            return True
        if t == "Электричество" and character.IncElecDMG == 2:
            return True
        return False

    # ------------------------------------------------------------------
    # тут вся логика боёв, интерфейс, обучение и т.д.
    # ------------------------------------------------------------------
    def _print_player_skills(self):
        character = ch_module.character
        for skill_id in character.skill_ids:
            skill = character.skills[skill_id]
            cost_text = ""
            if skill.get("costhp", 0) > 0:
                cost_text = f" - {skill['costhp']} HP"
            if skill.get("costsp", 0) > 0:
                cost_text = f" - {skill['costsp']} SP"
            can_use = "✓" if character.can_use_skill(skill_id) else "✗"
            print(f"{can_use} {skill['name']}{cost_text}")

    # ------------------------------------------------------------------
    # конец боевой механики, дальше идут конкретные реализации битв и обучение
    # ------------------------------------------------------------------
    def end_tutorial_battle(self):
        character = ch_module.character
        enemy = ch_module.enemy
        print("\n\n\n\n\nБитва окончена!")
        if character.hp <= 0:
            print("Вы проиграли битву...")
            self._on_player_death()
            return
        print("Вы выиграли битву!")
        character.add_exp(enemy.give_exp)
        character.souls += getattr(enemy, "give_souls", 0)
        print(f"Вы получили {enemy.give_exp} опыта!")
        if getattr(enemy, "give_souls", 0) > 0:
            print(f"Вы получили {enemy.give_souls} душ!")

    def start_tutorial_battle(self):
        character = ch_module.character
        enemy = ch_module.enemy
        playerturn = ch_module.playerturn
        enemyturn = ch_module.enemyturn
        tutorial_battle_state = ch_module.tutorial_battle_state

        while tutorial_battle_state:
            print("\n[ОБУЧЕНИЕ] Сейчас вы будете сражаться с врагом.")
            print("СИЛ усиливает физические атаки, МАГ — магические (Огонь/Лед/Электричество).")
            print("ЗАЩ снижает получаемый урон, ТОЧ влияет на шанс попасть, УДЧ — на шанс критического удара.")
            print("Попадание по слабости или критический удар дают бонус к жетонам хода.")
            first_player_turn = True
            first_enemy_turn = True
            playerturn = 3
            enemyturn = 3
            while enemy.hp > 0 and character.hp > 0:
                while playerturn > 0:
                    if first_player_turn:
                        print("\n(Теперь вы в бою с противником.)")
                        print("(Выберите действие для атаки или использования умения.)")
                        print("(Обратите внимание на свою статистику и слабости врага.)\n")
                        first_player_turn = False
                    else:
                        print("\n(Ваш ход.)\n")
                    print("Осталось", playerturn, "жетонов хода.")
                    print("-----Твоя статистика-----")
                    print("HP=", character.hp)
                    print("SP=", character.sp)
                    print("-----Умения-----")
                    self._print_player_skills()
                    print("\n-----Статистика врага-----")
                    print(f"Имя: {enemy.name}")
                    print("HP=", enemy.hp)
                    choice = input("Введите название умения:").strip()
                    skill_id, skill = character.get_skill_by_name(choice)
                    if skill_id and character.can_use_skill(skill_id):
                        print(f"Вы используете {skill['name']}!")
                        character.hp -= skill.get("costhp", 0)
                        character.sp -= skill.get("costsp", 0)
                        weak_hit = False
                        is_crit = False
                        if skill.get("type") == "Востановление":
                            heal = skill.get("heal", 0)
                            character.hp = min(character.hp + heal, character.maxhp)
                            print(f"Вы восстановили {heal} HP!")
                            playerturn -= 1
                        else:
                            hit_chance = self._calc_hit_chance(
                                character.get_effective_stat("ТОЧ"),
                                enemy.stats.get("ТОЧ", 0)
                            )
                            if random.random() > hit_chance:
                                print(f"{character.name} промахнулся!")
                                playerturn -= 1
                                continue

                            damage = self._compute_player_damage(skill, enemy)
                            crit_chance = self._calc_crit_chance(
                                character.get_effective_stat("УДЧ"),
                                enemy.stats.get("УДЧ", 0)
                            )
                            if random.random() < crit_chance:
                                is_crit = True
                                damage = int(damage * 1.5)
                                print("Критический удар!")

                            damage = self._apply_defense(damage, enemy.stats.get("ЗАЩ", 0))
                            enemy.hp -= damage
                            print(f"{enemy.name} потерял {damage} здоровья!")
                            if skill.get("effect"):
                                print(f"На {enemy.name} наложен эффект: {skill['effect']}")
                            weak_hit = self._is_weak_hit_on_enemy(skill, enemy)

                            if weak_hit or is_crit:
                                playerturn -= 0.5
                            else:
                                playerturn -= 1
                    else:
                        print("Вы пропустили ход или умение недоступно.")
                        playerturn -= 0.5
                    if enemy.hp <= 0:
                        print(f"{enemy.name} побежден!")
                        break
                else:
                    if first_enemy_turn:
                        print("\n++++++++++Ход врага++++++++++")
                        print("(Враг тоже может промахнуться, нанести критический удар или попасть по вашей слабости.)\n")
                        first_enemy_turn = False
                    else:
                        print("\n++++++++++Ход врага++++++++++\n")
                    enemyturn = 3
                    while enemyturn > 0 and enemy.hp > 0:
                        print(f"{enemy.name} turn!")
                        print("Осталось", enemyturn, "жетонов хода.")
                        skill_id = enemy.get_random_skill()
                        if skill_id:
                            skill = enemy.skills[skill_id]
                            print(f"{enemy.name} использует {skill['name']}!")
                            enemy.hp -= skill.get("costhp", 0)
                            enemy.sp -= skill.get("costsp", 0)
                            weak_hit = False
                            is_crit = False
                            if skill.get("type") == "Востановление":
                                heal = skill.get("heal", 0)
                                enemy.hp = min(enemy.hp + heal, enemy.maxhp)
                                print(f"{enemy.name} восстановил {heal} HP!")
                                enemyturn -= 1
                            else:
                                hit_chance = self._calc_hit_chance(
                                    enemy.stats.get("ТОЧ", 0),
                                    character.get_effective_stat("ТОЧ")
                                )
                                if random.random() > hit_chance:
                                    print(f"{enemy.name} промахнулся!")
                                    enemyturn -= 1
                                    continue

                                damage = self._compute_enemy_damage(skill, enemy)
                                crit_chance = self._calc_crit_chance(
                                    enemy.stats.get("УДЧ", 0),
                                    character.get_effective_stat("УДЧ")
                                )
                                if random.random() < crit_chance:
                                    is_crit = True
                                    damage = int(damage * 1.5)
                                    print("Критический удар врага!")

                                damage = self._apply_defense(damage, character.get_effective_stat("ЗАЩ"))
                                character.hp -= damage
                                print(f"{enemy.name} нанес {damage} урона!")
                                if skill.get("effect"):
                                    print(f"На {character.name} наложен эффект: {skill['effect']}")
                                weak_hit = self._is_weak_hit_on_player(skill)

                                if weak_hit or is_crit:
                                    enemyturn -= 0.5
                                else:
                                    enemyturn -= 1
                        else:
                            print(f"{enemy.name} не может использовать умения!")
                            enemyturn -= 1
                    if character.hp <= 0:
                        print(f"{character.name} побежден!")
                        break
                    else:
                        playerturn = 3
            tutorial_battle_state = False
            ch_module.tutorial_battle_state = False
            self.end_tutorial_battle()

    def start_battle(self):
        """Обычная битва без обучающих подсказок (для случайных/скриптовых сражений)."""
        character = ch_module.character
        playerturn = 3
        enemyturn = 3
        ch_module.playerturn = playerturn
        ch_module.enemyturn = enemyturn
        print("\nВы вступаете в бой!")
        enemy = ch_module.enemy
        while enemy.hp > 0 and character.hp > 0:
            # ход игрока
            while playerturn > 0 and enemy.hp > 0 and character.hp > 0:
                print("\n(Ваш ход.)")
                print("Осталось", playerturn, "жетонов хода.")
                print("HP=", character.hp, "SP=", character.sp)
                print("-----Умения-----")
                self._print_player_skills()
                print("\nВведите название умения, 'Предмет' для использования предмета или 'Бежать' для попытки побега.")
                print("\n-----Враг-----")
                print(f"Имя: {enemy.name}")
                print("HP=", enemy.hp)
                choice = input("Введите название умения:").strip()
                if choice.lower() in ("предмет", "item", "предметы"):
                    used, _ = self._use_item_in_battle()
                    if used:
                        playerturn -= 1
                    continue
                if choice.lower() in ("бежать", "run", "escape"):
                    escape_chance = self._calc_hit_chance(
                        character.get_effective_stat("ТОЧ"),
                        enemy.stats.get("ТОЧ", 0),
                        base=0.5
                    )
                    escape_chance = max(0.2, min(0.95, escape_chance))
                    if random.random() < escape_chance:
                        print("Вы успешно сбежали из боя!")
                        return
                    else:
                        print("Сбежать не удалось... Ход передается врагу...")
                        playerturn -= 3
                        continue
                skill_id, skill = character.get_skill_by_name(choice)
                if skill_id and character.can_use_skill(skill_id):
                    print(f"Вы используете {skill['name']}!")
                    character.hp -= skill.get("costhp", 0)
                    character.sp -= skill.get("costsp", 0)
                    weak_hit = False
                    is_crit = False
                    if skill.get("type") == "Востановление":
                        heal = skill.get("heal", 0)
                        character.hp = min(character.hp + heal, character.maxhp)
                        print(f"Вы восстановили {heal} HP!")
                        playerturn -= 1
                    else:
                        hit_chance = self._calc_hit_chance(
                            character.get_effective_stat("ТОЧ"),
                            enemy.stats.get("ТОЧ", 0)
                        )
                        if random.random() > hit_chance:
                            print(f"{character.name} промахнулся!")
                            playerturn -= 2
                            continue

                        damage = self._compute_player_damage(skill, enemy)
                        crit_chance = self._calc_crit_chance(
                            character.get_effective_stat("УДЧ"),
                            enemy.stats.get("УДЧ", 0)
                        )
                        if random.random() < crit_chance:
                            is_crit = True
                            damage = int(damage * 1.5)
                            print("Критический удар!")

                        damage = self._apply_defense(damage, enemy.stats.get("ЗАЩ", 0))
                        enemy.hp -= damage
                        print(f"{enemy.name} потерял {damage} здоровья!")
                        if skill.get("effect"):
                            print(f"На {enemy.name} наложен эффект: {skill['effect']}")
                        weak_hit = self._is_weak_hit_on_enemy(skill, enemy)

                        if weak_hit or is_crit:
                            playerturn -= 0.5
                        else:
                            playerturn -= 1
                else:
                    print("Вы пропустили ход или умение недоступно.")
                    playerturn -= 0.5

                if enemy.hp <= 0:
                    print(f"{enemy.name} побежден!")
                    break

            if enemy.hp <= 0 or character.hp <= 0:
                break

            # ход врага
            print("\n++++++++++Ход врага++++++++++\n")
            enemyturn = 3
            while enemyturn > 0 and enemy.hp > 0 and character.hp > 0:
                print(f"{enemy.name} turn!")
                print("Осталось", enemyturn, "жетонов хода.")
                skill_id = enemy.get_random_skill()
                if skill_id:
                    skill = enemy.skills[skill_id]
                    print(f"{enemy.name} использует {skill['name']}!")
                    enemy.hp -= skill.get("costhp", 0)
                    enemy.sp -= skill.get("costsp", 0)
                    weak_hit = False
                    is_crit = False
                    if skill.get("type") == "Востановление":
                        heal = skill.get("heal", 0)
                        enemy.hp = min(enemy.hp + heal, enemy.maxhp)
                        print(f"{enemy.name} восстановил {heal} HP!")
                        enemyturn -= 1
                    else:
                        hit_chance = self._calc_hit_chance(
                            enemy.stats.get("ТОЧ", 0),
                            character.get_effective_stat("ТОЧ")
                        )
                        if random.random() > hit_chance:
                            print(f"{enemy.name} промахнулся!")
                            enemyturn -= 1
                            continue

                        damage = self._compute_enemy_damage(skill, enemy)
                        crit_chance = self._calc_crit_chance(
                            enemy.stats.get("УДЧ", 0),
                            character.get_effective_stat("УДЧ")
                        )
                        if random.random() < crit_chance:
                            is_crit = True
                            damage = int(damage * 1.5)
                            print("Критический удар врага!")

                        damage = self._apply_defense(damage, character.get_effective_stat("ЗАЩ"))
                        character.hp -= damage
                        print(f"{enemy.name} нанес {damage} урона!")
                        if skill.get("effect"):
                            print(f"На {character.name} наложен эффект: {skill['effect']}")
                        weak_hit = self._is_weak_hit_on_player(skill)

                        if weak_hit or is_crit:
                            enemyturn -= 0.5
                        else:
                            enemyturn -= 1
                else:
                    print(f"{enemy.name} не может использовать умения!")
                    enemyturn -= 1

            if character.hp <= 0 or enemy.hp <= 0:
                break

            playerturn = 3

        if character.hp <= 0:
            print(f"{character.name} пал в бою...")
            self._on_player_death()
        elif enemy.hp <= 0:
            print(f"{character.name} победил {enemy.name}!")
            character.add_exp(enemy.give_exp)
            character.souls += getattr(enemy, "give_souls", 0)
            print(f"Получено: {enemy.give_exp} опыта, {getattr(enemy, 'give_souls', 0)} душ.")

    def start_lizard_battle(self):
        """Специальная битва с ящерицей на мосту, использующей Апофего каждые 2 хода."""
        character = ch_module.character
        enemy = ch_module.enemy
        playerturn = 3
        enemyturn = 3
        apofego_turns_left = 0
        enemy_turn_counter = 0
        apofego_skill = ALLskills.get("14")

        print("\nВы вступаете в бой с ящерицей!")
        while enemy.hp > 0 and character.hp > 0:
            # ход игрока
            while playerturn > 0 and enemy.hp > 0 and character.hp > 0:
                print("\n(Ваш ход.)")
                print("Осталось", playerturn, "жетонов хода.")
                print("HP=", character.hp, "SP=", character.sp)
                print("-----Умения-----")
                self._print_player_skills()
                print("\n-----Враг-----")
                print(f"Имя: {enemy.name}")
                print("HP=", enemy.hp)
                if apofego_turns_left > 0:
                    print("(Ящерица окутана защитой Апофего — уклонение повышено!)")
                choice = input("Введите название умения:").strip()
                if choice.lower() in ("предмет", "item", "предметы"):
                    used, _ = self._use_item_in_battle()
                    if used:
                        playerturn -= 1
                    continue
                skill_id, skill = character.get_skill_by_name(choice)
                if skill_id and character.can_use_skill(skill_id):
                    print(f"Вы используете {skill['name']}!")
                    character.hp -= skill.get("costhp", 0)
                    character.sp -= skill.get("costsp", 0)
                    weak_hit = False
                    is_crit = False
                    if skill.get("type") == "Востановление":
                        heal = skill.get("heal", 0)
                        character.hp = min(character.hp + heal, character.maxhp)
                        print(f"Вы восстановили {heal} HP!")
                        playerturn -= 1
                    else:
                        hit_chance = self._calc_hit_chance(
                            character.get_effective_stat("ТОЧ"),
                            enemy.stats.get("ТОЧ", 0)
                        )
                        if apofego_turns_left > 0:
                            hit_chance *= 0.5
                        hit_chance = max(0.1, min(0.98, hit_chance))
                        if random.random() > hit_chance:
                            print(f"{character.name} промахнулся! Ящерица уклоняется.")
                            playerturn -= 1
                            continue

                        damage = self._compute_player_damage(skill, enemy)
                        crit_chance = self._calc_crit_chance(
                            character.get_effective_stat("УДЧ"),
                            enemy.stats.get("УДЧ", 0)
                        )
                        if random.random() < crit_chance:
                            is_crit = True
                            damage = int(damage * 1.5)
                            print("Критический удар!")

                        damage = self._apply_defense(damage, enemy.stats.get("ЗАЩ", 0))
                        enemy.hp -= damage
                        print(f"{enemy.name} потерял {damage} здоровья!")
                        if skill.get("effect"):
                            print(f"На {enemy.name} наложен эффект: {skill['effect']}")
                        weak_hit = self._is_weak_hit_on_enemy(skill, enemy)

                        if weak_hit or is_crit:
                            playerturn -= 0.5
                        else:
                            playerturn -= 1
                else:
                    print("Вы пропустили ход или умение недоступно.")
                    playerturn -= 0.5

                if enemy.hp <= 0:
                    print(f"{enemy.name} побежден!")
                    break

            if enemy.hp <= 0 or character.hp <= 0:
                break

            # ход врага (ящерицы)
            print("\n++++++++++Ход ящерицы++++++++++\n")
            enemyturn = 3
            enemy_turn_counter += 1

            if apofego_skill and enemy.sp < apofego_skill.get("costsp", 0):
                print(f"{enemy.name} в ужасе понимает, что не может больше использовать {apofego_skill['name']} и сбегает!")
                print("'Мы еще встретимся...'")
                enemy.hp = 0
                break

            if apofego_skill and apofego_turns_left == 0 and enemy_turn_counter % 2 == 0 and enemy.sp >= apofego_skill.get("costsp", 0):
                print(f"{enemy.name} использует {apofego_skill['name']}!")
                enemy.sp -= apofego_skill.get("costsp", 0)
                apofego_turns_left = 2
                enemyturn -= 1

            while enemyturn > 0 and enemy.hp > 0 and character.hp > 0:
                if enemyturn <= 0:
                    break
                print(f"{enemy.name} turn!")
                print("Осталось", enemyturn, "жетонов хода.")

                skill_id = random.choice(["1", "10"]) if (enemy.can_use_skill("1") or enemy.can_use_skill("10")) else enemy.get_random_skill()
                if skill_id:
                    skill = enemy.skills[skill_id]
                    print(f"{enemy.name} использует {skill['name']}!")
                    enemy.hp -= skill.get("costhp", 0)
                    enemy.sp -= skill.get("costsp", 0)
                    weak_hit = False
                    is_crit = False
                    if skill.get("type") == "Востановление":
                        heal = skill.get("heal", 0)
                        enemy.hp = min(enemy.hp + heal, enemy.maxhp)
                        print(f"{enemy.name} восстановил {heal} HP!")
                        enemyturn -= 1
                    else:
                        hit_chance = self._calc_hit_chance(
                            enemy.stats.get("ТОЧ", 0),
                            character.get_effective_stat("ТОЧ")
                        )
                        if random.random() > hit_chance:
                            print(f"{enemy.name} промахнулся!")
                            enemyturn -= 1
                            continue

                        damage = self._compute_enemy_damage(skill, enemy)
                        crit_chance = self._calc_crit_chance(
                            enemy.stats.get("УДЧ", 0),
                            character.get_effective_stat("УДЧ")
                        )
                        if random.random() < crit_chance:
                            is_crit = True
                            damage = int(damage * 1.5)
                            print("Критический удар врага!")

                        damage = self._apply_defense(damage, character.get_effective_stat("ЗАЩ"))
                        character.hp -= damage
                        print(f"{enemy.name} нанес {damage} урона!")
                        if skill.get("effect"):
                            print(f"На {character.name} наложен эффект: {skill['effect']}")
                        weak_hit = self._is_weak_hit_on_player(skill)

                        if weak_hit or is_crit:
                            enemyturn -= 0.5
                        else:
                            enemyturn -= 1
                else:
                    print(f"{enemy.name} не может использовать умения!")
                    enemyturn -= 1

            if apofego_turns_left > 0:
                apofego_turns_left -= 1

            if character.hp <= 0 or enemy.hp <= 0:
                break

            playerturn = 3

        if character.hp <= 0:
            print(f"{character.name} пал в бою от лап ящерицы...")
            self._on_player_death()
        elif enemy.hp <= 0:
            print(f"{character.name} победил {enemy.name} на мосту!")
            character.add_exp(enemy.give_exp)
            character.souls += getattr(enemy, "give_souls", 0)
            print(f"Получено: {enemy.give_exp} опыта, {getattr(enemy, 'give_souls', 0)} душ.")
            ch_module.quest_monster_bridge_completed = True
            print("*Квест с монстром на мосту выполнен.*")

    def start_minotaur_battle(self):
        """Особый бой с Минотавром: его нельзя убить, достаточно немного ранить — он убежит."""
        character = ch_module.character
        enemy = ch_module.minotaur
        ch_module.enemy = enemy
        enemy.hp = enemy.maxhp
        enemy.sp = enemy.maxsp
        playerturn = 3
        enemyturn = 3
        damaged = False
        total_damage = 0

        print("\nВы слышите тяжёлое дыхание... Перед вами появляется Минотавр!")
        while enemy.hp > 0 and character.hp > 0 and not damaged:
            while playerturn > 0 and enemy.hp > 0 and character.hp > 0 and not damaged:
                print("\n(Ваш ход против Минотавра.)")
                print("Осталось", playerturn, "жетонов хода.")
                print("HP=", character.hp, "SP=", character.sp)
                print("-----Умения-----")
                self._print_player_skills()
                print("\n-----Минотавр-----")
                print(f"Имя: {enemy.name}")
                print("HP=", enemy.hp)
                choice = input("Введите название умения:").strip()
                if choice.lower() in ("предмет", "item", "предметы"):
                    used, _ = self._use_item_in_battle()
                    if used:
                        playerturn -= 1
                    continue
                skill_id, skill = character.get_skill_by_name(choice)
                if not (skill_id and character.can_use_skill(skill_id)):
                    print("Вы пропускаете возможность ударить Минотавра.")
                    playerturn -= 0.5
                    continue

                print(f"Вы используете {skill['name']}!")
                character.hp -= skill.get("costhp", 0)
                character.sp -= skill.get("costsp", 0)

                if skill.get("type") == "Востановление":
                    heal = skill.get("heal", 0)
                    character.hp = min(character.hp + heal, character.maxhp)
                    print(f"Вы восстановили {heal} HP!")
                    playerturn -= 1
                    continue

                hit_chance = self._calc_hit_chance(
                    character.get_effective_stat("ТОЧ"),
                    enemy.stats.get("ТОЧ", 0)
                )
                if random.random() > hit_chance:
                    print(f"{character.name} промахнулся!")
                    playerturn -= 2
                    continue

                damage = self._compute_player_damage(skill, enemy)
                damage = self._apply_defense(damage, enemy.stats.get("ЗАЩ", 0))
                enemy.hp -= damage
                total_damage += damage
                print(f"{enemy.name} потерял {damage} здоровья!")
                if total_damage >= 100:
                    damaged = True
                    print("*Минотавр ревёт от боли!*")
                    print("'Достаточно... Я не хочу умирать...'")
                    print("*Покачнувшись, Минотавр разворачивается и в панике убегает по коридорам лабиринта.*")
                    break

                playerturn -= 1

            if damaged or character.hp <= 0:
                break

            print("\n++++++++++Ход Минотавра++++++++++\n")
            enemyturn = 1
            while enemyturn > 0 and character.hp > 0 and not damaged:
                skill_id = enemy.get_random_skill()
                if not skill_id:
                    print(f"{enemy.name} колеблется и не атакует.")
                    enemyturn -= 1
                    continue
                skill = enemy.skills[skill_id]
                print(f"{enemy.name} использует {skill['name']}!")
                enemy.hp -= skill.get("costhp", 0)
                enemy.sp -= skill.get("costsp", 0)

                if skill.get("type") == "Востановление":
                    heal = skill.get("heal", 0)
                    enemy.hp = min(enemy.hp + heal, enemy.maxhp)
                    print(f"{enemy.name} восстановил {heal} HP!")
                    enemyturn -= 1
                    continue

                hit_chance = self._calc_hit_chance(
                    enemy.stats.get("ТОЧ", 0),
                    character.get_effective_stat("ТОЧ"),
                    base=0.75
                )
                if random.random() > hit_chance:
                    print(f"{enemy.name} промахнулся!")
                    enemyturn -= 1
                    continue

                damage = self._compute_enemy_damage(skill, enemy)
                damage = self._apply_defense(damage, character.get_effective_stat("ЗАЩ"))
                character.hp -= damage
                print(f"{enemy.name} нанес {damage} урона!")
                enemyturn -= 1

        if character.hp <= 0:
            print(f"{character.name} пал в коридорах лабиринта...")
            self._on_player_death()
        elif damaged:
            print("*Кажется, Минотавр убежал в глубины лабиринта. Путь снова свободен...*")

    def start_titan_koi_battle(self):
        """Бой с титаном Коем — тяжёлый затяжной бой."""
        character = ch_module.character
        enemy = ch_module.titan_koi
        ch_module.enemy = enemy
        enemy.hp = enemy.maxhp
        enemy.sp = enemy.maxsp
        playerturn = 3
        enemyturn = 3
        self.koi_blind_for_next_strike = False
        koi_round_counter = 0

        print("\nЗемля содрогается... Перед вами встаёт Титан Кой!")
        while enemy.hp > 0 and character.hp > 0:
            koi_round_counter += 1
            while playerturn > 0 and enemy.hp > 0 and character.hp > 0:
                print("\n(Ваш ход против Коя.)")
                print("Осталось", playerturn, "жетонов хода.")
                print("HP=", character.hp, "SP=", character.sp)
                print("-----Умения-----")
                self._print_player_skills()
                print("\n-----Титан Кой-----")
                print(f"Имя: {enemy.name}")
                print("HP=", enemy.hp)
                choice = input("Введите название умения:").strip()
                if choice.lower() in ("предмет", "item", "предметы"):
                    used, item_id = self._use_item_in_battle()
                    if used:
                        if item_id == "gorgon_head":
                            self.koi_blind_for_next_strike = True
                        playerturn -= 1
                    continue
                skill_id, skill = character.get_skill_by_name(choice)
                if not (skill_id and character.can_use_skill(skill_id)):
                    print("Вы пропустили ход или умение недоступно.")
                    playerturn -= 0.5
                    continue

                print(f"Вы используете {skill['name']}!")
                character.hp -= skill.get("costhp", 0)
                character.sp -= skill.get("costsp", 0)

                if skill.get("type") == "Востановление":
                    heal = skill.get("heal", 0)
                    character.hp = min(character.hp + heal, character.maxhp)
                    print(f"Вы восстановили {heal} HP!")
                    playerturn -= 1
                    continue

                hit_chance = self._calc_hit_chance(
                    character.get_effective_stat("ТОЧ"),
                    enemy.stats.get("ТОЧ", 0)
                )
                if random.random() > hit_chance:
                    print(f"{character.name} промахнулся!")
                    playerturn -= 1
                    continue

                damage = self._compute_player_damage(skill, enemy)
                damage = self._apply_defense(damage, enemy.stats.get("ЗАЩ", 0))
                enemy.hp -= damage
                print(f"{enemy.name} потерял {damage} здоровья!")
                playerturn -= 1

            if enemy.hp <= 0 or character.hp <= 0:
                break

            print("\n++++++++++Ход Титана Коя++++++++++\n")
            if koi_round_counter % 10 == 0:
                print("Титан Кой поднимает руку к небу... 'Рука Бога' обрушивается на вас!")
                if getattr(self, "koi_blind_for_next_strike", False):
                    print("Но взгляд Медузы искажает траекторию удара — вы чудом избегаете неминуемой гибели.")
                    self.koi_blind_for_next_strike = False
                else:
                    character.hp -= 99999
                    print("Непостижимая сила поражает вас, нанося 99999 урона!")
                    if character.hp <= 0:
                        break
            enemyturn = 3
            while enemyturn > 0 and enemy.hp > 0 and character.hp > 0:
                skill_id = enemy.get_random_skill()
                if not skill_id:
                    print(f"{enemy.name} не может использовать умения!")
                    enemyturn -= 1
                    continue
                skill = enemy.skills[skill_id]
                print(f"{enemy.name} использует {skill['name']}!")
                enemy.hp -= skill.get("costhp", 0)
                enemy.sp -= skill.get("costsp", 0)

                if skill.get("type") == "Востановление":
                    heal = skill.get("heal", 0)
                    enemy.hp = min(enemy.hp + heal, enemy.maxhp)
                    print(f"{enemy.name} восстановил {heal} HP!")
                    enemyturn -= 1
                    continue

                hit_chance = self._calc_hit_chance(
                    enemy.stats.get("ТОЧ", 0),
                    character.get_effective_stat("ТОЧ")
                )
                if random.random() > hit_chance:
                    print(f"{enemy.name} промахнулся!")
                    enemyturn -= 1
                    continue

                damage = self._compute_enemy_damage(skill, enemy)
                damage = self._apply_defense(damage, character.get_effective_stat("ЗАЩ"))
                character.hp -= damage
                print(f"{enemy.name} наносит {damage} урона!")
                enemyturn -= 1

            if character.hp <= 0 or enemy.hp <= 0:
                break
            playerturn = 3

        if character.hp <= 0:
            print(f"{character.name} пал в битве с Титаном Коем...")
            self._on_player_death()
        else:
            print(f"{character.name} одолел Титана Коя!")
            character.add_exp(enemy.give_exp)
            character.souls += getattr(enemy, "give_souls", 0)
            print(f"Получено: {enemy.give_exp} опыта, {getattr(enemy, 'give_souls', 0)} душ.")

    def start_leopard_duo_battle(self):
        """Битва с двумя леопардами: красным (магия) и синим (физические атаки)."""
        character = ch_module.character
        r = ch_module.red_leopard
        b = ch_module.blue_leopard
        r.hp, r.sp = r.maxhp, r.maxsp
        b.hp, b.sp = b.maxhp, b.maxsp
        playerturn = 3
        buff_applied = False

        print("\nВы вступаете в бой с двумя леопардами!")
        print(f"Перед вами {r.name} и {b.name}.")

        while character.hp > 0 and (r.hp > 0 or b.hp > 0):
            playerturn = 3
            while playerturn > 0 and character.hp > 0 and (r.hp > 0 or b.hp > 0):
                print("\n(Ваш ход.)")
                print("Осталось", playerturn, "жетонов хода.")
                print("HP=", character.hp, "SP=", character.sp)
                print("-----Умения-----")
                self._print_player_skills()
                print("\n-----Враги-----")
                print(f"{r.name}: HP {max(r.hp, 0)}/{r.maxhp}")
                print(f"{b.name}: HP {max(b.hp, 0)}/{b.maxhp}")
                print("Введите название умения или 'Предмет' для использования предмета.")

                choice = input("Введите название умения:").strip()
                if choice.lower() in ("предмет", "item", "предметы"):
                    used, _ = self._use_item_in_battle()
                    if used:
                        playerturn -= 1
                    continue
                skill_id, skill = character.get_skill_by_name(choice)
                if not (skill_id and character.can_use_skill(skill_id)):
                    print("Вы пропустили ход или умение недоступно.")
                    playerturn -= 0.5
                    continue

                print(f"Вы используете {skill['name']}!")
                character.hp -= skill.get("costhp", 0)
                character.sp -= skill.get("costsp", 0)
                weak_hit = False
                is_crit = False

                if skill.get("type") == "Востановление":
                    heal = skill.get("heal", 0)
                    character.hp = min(character.hp + heal, character.maxhp)
                    print(f"Вы восстановили {heal} HP!")
                    playerturn -= 1
                    continue

                target = None
                if r.hp > 0 and b.hp > 0:
                    while True:
                        target_choice = input("Кого атаковать? (красный/синий): ").strip().lower()
                        if target_choice in ("красный", "red"):
                            target = r
                            break
                        elif target_choice in ("синий", "blue"):
                            target = b
                            break
                        else:
                            print("Неверный выбор цели.")
                elif r.hp > 0:
                    target = r
                    print(f"Вы атакуете {r.name}.")
                elif b.hp > 0:
                    target = b
                    print(f"Вы атакуете {b.name}.")
                else:
                    break

                hit_chance = self._calc_hit_chance(
                    character.get_effective_stat("ТОЧ"),
                    target.stats.get("ТОЧ", 0)
                )
                if random.random() > hit_chance:
                    print(f"{character.name} промахнулся по {target.name}!")
                    playerturn -= 1
                    continue

                damage = self._compute_player_damage(skill, target)
                crit_chance = self._calc_crit_chance(
                    character.get_effective_stat("УДЧ"),
                    target.stats.get("УДЧ", 0)
                )
                if random.random() < crit_chance:
                    is_crit = True
                    damage = int(damage * 1.5)
                    print("Критический удар!")

                damage = self._apply_defense(damage, target.stats.get("ЗАЩ", 0))
                target.hp -= damage
                print(f"{target.name} потерял {damage} здоровья!")
                if skill.get("effect"):
                    print(f"На {target.name} наложен эффект: {skill['effect']}")
                weak_hit = self._is_weak_hit_on_enemy(skill, target)

                if weak_hit or is_crit:
                    playerturn -= 0.5
                else:
                    playerturn -= 1

                if not buff_applied and ((r.hp <= 0 and b.hp > 0) or (b.hp <= 0 and r.hp > 0)):
                    survivor = b if b.hp > 0 else r
                    print(f"{survivor.name} впадает в ярость из-за гибели напарника!")
                    survivor.stats["СИЛ"] += 3
                    survivor.stats["МАГ"] += 3
                    survivor.stats["ЗАЩ"] += 3
                    survivor.stats["ТОЧ"] += 3
                    survivor.stats["УДЧ"] += 2
                    buff_applied = True

            if character.hp <= 0 or (r.hp <= 0 and b.hp <= 0):
                break

            enemy_tokens = 4
            print("\n++++++++++Ход леопардов++++++++++\n")
            current_is_red = True
            while enemy_tokens > 0 and character.hp > 0 and (r.hp > 0 or b.hp > 0):
                attacker = None
                if current_is_red and r.hp > 0:
                    attacker = r
                elif (not current_is_red) and b.hp > 0:
                    attacker = b
                else:
                    if r.hp > 0:
                        attacker = r
                        current_is_red = True
                    elif b.hp > 0:
                        attacker = b
                        current_is_red = False
                    else:
                        break

                print(f"{attacker.name} ходит! Осталось общих жетонов: {enemy_tokens}.")
                skill_id = attacker.get_random_skill()
                if not skill_id:
                    print(f"{attacker.name} не может использовать умения!")
                    enemy_tokens -= 1
                    current_is_red = not current_is_red
                    continue

                skill = attacker.skills[skill_id]
                print(f"{attacker.name} использует {skill['name']}!")
                attacker.hp -= skill.get("costhp", 0)
                attacker.sp -= skill.get("costsp", 0)
                weak_hit = False
                is_crit = False

                if skill.get("type") == "Востановление":
                    heal = skill.get("heal", 0)
                    attacker.hp = min(attacker.hp + heal, attacker.maxhp)
                    print(f"{attacker.name} восстановил {heal} HP!")
                    enemy_tokens -= 1
                    current_is_red = not current_is_red
                    continue

                hit_chance = self._calc_hit_chance(
                    attacker.stats.get("ТОЧ", 0),
                    character.get_effective_stat("ТОЧ")
                )
                if random.random() > hit_chance:
                    print(f"{attacker.name} промахнулся!")
                    enemy_tokens -= 1
                    current_is_red = not current_is_red
                    continue

                damage = self._compute_enemy_damage(skill, attacker)
                crit_chance = self._calc_crit_chance(
                    attacker.stats.get("УДЧ", 0),
                    character.get_effective_stat("УДЧ")
                )
                if random.random() < crit_chance:
                    is_crit = True
                    damage = int(damage * 1.5)
                    print("Критический удар врага!")

                damage = self._apply_defense(damage, character.get_effective_stat("ЗАЩ"))
                character.hp -= damage
                print(f"{attacker.name} нанес {damage} урона!")
                weak_hit = self._is_weak_hit_on_player(skill)

                if weak_hit or is_crit:
                    enemy_tokens -= 0.5
                else:
                    enemy_tokens -= 1

                current_is_red = not current_is_red

            if character.hp <= 0 or (r.hp <= 0 and b.hp <= 0):
                break

        if character.hp <= 0:
            print(f"{character.name} пал в бою от леопардов...")
            self._on_player_death()
        else:
            print(f"{character.name} победил красного и синего леопардов!")
            total_exp = (r.give_exp if r.hp <= 0 else 0) + (b.give_exp if b.hp <= 0 else 0)
            total_souls = getattr(r, "give_souls", 0) + getattr(b, "give_souls", 0)
            character.add_exp(total_exp)
            character.souls += total_souls
            print(f"Получено: {total_exp} опыта, {total_souls} душ.")


    def start_gela_arei_battle(self):
        """
        Бой с Геласием и Арейей, слившимися в единое существо.

        (блин ей богу один из самых ужасных боев что я придумал)

        Цикл раунда:
          1. ФАЗА БАФФА (2 хода существа): случайный бафф на себя (СИЛ/ЗАЩ/ТОЧ),
             только один активный бафф за раз; между атаками — обычные удары.
          2. ФАЗА ДЕБАФФА (1 ход существа): когда бафф спадает, существо
             накладывает соответствующий дебафф на игрока на 2 хода игрока.
          3. ФАЗА СЛАБОСТИ: существо падает без сил — игрок получает 1 бесплатный
             удар (без затраты жетонов).
          4. ИСЦЕЛЕНИЕ: небольшое восстановление HP обоим; цикл начинается заново.

        В промежутках существо атакует как обычно (из GELASI_SKILLS).
        """
        character = ch_module.character
        enemy = ch_module.gelassi
        ch_module.enemy = enemy
        enemy.hp = enemy.maxhp
        enemy.sp = enemy.maxsp

        # ---------- состояние боя ----------
        playerturn = 3

        # Активный бафф на существо: {"stat": str, "turns_left": int} или None
        active_buff = None
        # Активный дебафф на игрока: {"stat": str, "amount": int, "turns_left": int} или None
        active_debuff = None
        # Сколько ходов существа до следующего баффа (сбрасывается после слабости)
        turns_until_buff = 1   # сразу первый раунд начинается с баффа

        # Карта баффов → дебаффов (какой стат снижается у игрока)
        BUFF_TO_DEBUFF = {
            "СИЛ": ("ТОЧ",  2),   # бафф атаки → дебафф точности игрока
            "ЗАЩ": ("МАГ",  2),   # бафф защиты → дебафф магии игрока
            "ТОЧ": ("УДЧ",  2),   # бафф уклонения → дебафф удачи игрока
        }
        BUFF_NAMES = {
            "СИЛ": "Слияние Силы",
            "ЗАЩ": "Слияние Щита",
            "ТОЧ": "Слияние Уклонения",
        }
        DEBUFF_NAMES = {
            "ТОЧ": "Туман Разума",
            "МАГ": "Истощение Духа",
            "УДЧ": "Проклятие Судьбы",
        }
        BUFF_BONUSES = {"СИЛ": 4, "ЗАЩ": 5, "ТОЧ": 4}

        round_counter = 0

        print("\n*Земля трескается... Два силуэта сливаются в одно существо!*")
        print("*Геласий и Арейя — единое целое. Их сила ощущается как нечто запредельное.*")

        while enemy.hp > 0 and character.hp > 0:
            round_counter += 1

            # ---- Тик дебаффа игрока (уменьшаем счётчик в начале хода игрока) ----
            if active_debuff and active_debuff["turns_left"] > 0:
                active_debuff["turns_left"] -= 1
                if active_debuff["turns_left"] == 0:
                    # снимаем дебафф
                    stat = active_debuff["stat"]
                    character.stats[stat] += active_debuff["amount"]
                    print(f"\n*Дебафф {DEBUFF_NAMES.get(stat, stat)} спал. Ваша {stat} восстановлена.*")
                    active_debuff = None

            # ==== ХОД ИГРОКА ====
            while playerturn > 0 and enemy.hp > 0 and character.hp > 0:
                print("\n(Ваш ход.)")
                print("Осталось", playerturn, "жетонов хода.")
                print("HP=", character.hp, "SP=", character.sp)
                if active_debuff:
                    stat = active_debuff["stat"]
                    print(f"  [Дебафф: {DEBUFF_NAMES.get(stat, stat)} — {stat} снижена, осталось {active_debuff['turns_left']} ход(а)]")
                print("-----Умения-----")
                self._print_player_skills()
                print("\n-----Геласий и Арейя-----")
                print(f"HP= {enemy.hp}/{enemy.maxhp}  SP= {enemy.sp}/{enemy.maxsp}")
                if active_buff:
                    stat = active_buff["stat"]
                    print(f"  [Бафф: {BUFF_NAMES.get(stat, stat)} — {stat} усилена, осталось {active_buff['turns_left']} ход(а) существа]")
                print("\nВведите название умения или 'Предмет'.")
                choice = input("Введите название умения:").strip()

                if choice.lower() in ("предмет", "item", "предметы"):
                    used, _ = self._use_item_in_battle()
                    if used:
                        playerturn -= 1
                    continue

                skill_id, skill = character.get_skill_by_name(choice)
                if not (skill_id and character.can_use_skill(skill_id)):
                    print("Вы пропустили ход или умение недоступно.")
                    playerturn -= 0.5
                    continue

                print(f"Вы используете {skill['name']}!")
                character.hp -= skill.get("costhp", 0)
                character.sp -= skill.get("costsp", 0)
                weak_hit = False
                is_crit = False

                if skill.get("type") == "Востановление":
                    heal = skill.get("heal", 0)
                    character.hp = min(character.hp + heal, character.maxhp)
                    print(f"Вы восстановили {heal} HP!")
                    playerturn -= 1
                    continue

                hit_chance = self._calc_hit_chance(
                    character.get_effective_stat("ТОЧ"),
                    enemy.stats.get("ТОЧ", 0)
                )
                if random.random() > hit_chance:
                    print(f"{character.name} промахнулся!")
                    playerturn -= 1
                    continue

                damage = self._compute_player_damage(skill, enemy)
                crit_chance = self._calc_crit_chance(
                    character.get_effective_stat("УДЧ"),
                    enemy.stats.get("УДЧ", 0)
                )
                if random.random() < crit_chance:
                    is_crit = True
                    damage = int(damage * 1.5)
                    print("Критический удар!")

                damage = self._apply_defense(damage, enemy.stats.get("ЗАЩ", 0))
                enemy.hp -= damage
                print(f"Геласий и Арейя потеряли {damage} здоровья!")
                weak_hit = self._is_weak_hit_on_enemy(skill, enemy)

                if weak_hit or is_crit:
                    playerturn -= 0.5
                else:
                    playerturn -= 1

                if enemy.hp <= 0:
                    break

            if enemy.hp <= 0 or character.hp <= 0:
                break

            # ==== ХОД СУЩЕСТВА ====
            print("\n╔══════════════════════════════╗")
            print("║   Ход Геласия и Арейи...     ║")
            print("╚══════════════════════════════╝\n")

            # --- Фаза баффа: применяем/тикаем бафф ---
            if active_buff is None and turns_until_buff <= 0:
                # Выбираем случайный стат для баффа
                buff_stat = random.choice(list(BUFF_BONUSES.keys()))
                bonus = BUFF_BONUSES[buff_stat]
                enemy.stats[buff_stat] += bonus
                active_buff = {"stat": buff_stat, "turns_left": 2, "bonus": bonus}
                print(f"*Существо концентрирует слияние душ...*")
                print(f"*{BUFF_NAMES[buff_stat]}! {buff_stat} Геласия усилена на {bonus}!*")
            elif active_buff is not None:
                active_buff["turns_left"] -= 1
                if active_buff["turns_left"] <= 0:
                    # Бафф спадает → дебафф игроку
                    buff_stat = active_buff["stat"]
                    bonus = active_buff["bonus"]
                    enemy.stats[buff_stat] -= bonus   # снять бафф с существа
                    debuff_stat, debuff_amount = BUFF_TO_DEBUFF[buff_stat]
                    character.stats[debuff_stat] -= debuff_amount
                    active_debuff = {"stat": debuff_stat, "amount": debuff_amount, "turns_left": 2}
                    active_buff = None
                    print(f"*Слияние распадается... Энергия выплёскивается наружу!*")
                    print(f"*{DEBUFF_NAMES[debuff_stat]}! Ваша {debuff_stat} снижена на {debuff_amount} на 2 хода!*")

                    # === ФАЗА СЛАБОСТИ ===
                    print("\n*Существо падает на колени, опустошённое распадом слияния...*")
                    print("*Сейчас — ваш шанс! Один удар без затраты жетонов!*")
                    while True:
                        print("-----Умения-----")
                        self._print_player_skills()
                        free_choice = input("Нанесите удар (введите название умения):").strip()
                        free_id, free_skill = character.get_skill_by_name(free_choice)
                        if not (free_id and character.can_use_skill(free_id)):
                            print("Умение недоступно. Попробуйте другое.")
                            continue
                        if free_skill.get("type") == "Востановление":
                            print("Сейчас не лучшее время лечиться — нанесите атаку!")
                            continue
                        break

                    print(f"Вы используете {free_skill['name']}!")
                    character.hp -= free_skill.get("costhp", 0)
                    character.sp -= free_skill.get("costsp", 0)
                    free_damage = self._compute_player_damage(free_skill, enemy)
                    free_damage = self._apply_defense(free_damage, enemy.stats.get("ЗАЩ", 0))
                    enemy.hp -= free_damage
                    print(f"Вы наносите {free_damage} урона беззащитному существу!")

                    if enemy.hp <= 0:
                        break

                    # === ИСЦЕЛЕНИЕ ===
                    heal_amount = 25
                    character.hp = min(character.hp + heal_amount, character.maxhp)
                    enemy.hp = min(enemy.hp + heal_amount, enemy.maxhp)
                    print(f"\n*Вспышка тёплого света... Оба восстанавливают {heal_amount} HP.*")
                    print(f"*Слияние начинается заново...*")
                    turns_until_buff = 0   # сразу начать новый цикл баффа
                    playerturn = 3
                    continue
                else:
                    print(f"*{BUFF_NAMES[active_buff['stat']]} продолжает действовать "
                          f"({active_buff['turns_left']} ход(а) осталось).*")

            turns_until_buff -= 1

            # --- Обычные атаки существа (attack skills only, no buff skills) ---
            attack_skill_ids = [sid for sid in enemy.skill_ids
                                if ALLskills[sid].get("type") not in ("Бафф",)
                                and enemy.can_use_skill(sid)]
            enemy_tokens = 3
            while enemy_tokens > 0 and enemy.hp > 0 and character.hp > 0:
                if not attack_skill_ids:
                    print("*Существо истощено и не может атаковать.*")
                    enemy_tokens -= 1
                    continue
                sid = random.choice(attack_skill_ids)
                skill = enemy.skills[sid]
                print(f"Геласий и Арейя используют {skill['name']}!")
                enemy.hp -= skill.get("costhp", 0)
                enemy.sp -= skill.get("costsp", 0)
                weak_hit = False
                is_crit = False

                if skill.get("type") == "Востановление":
                    heal = skill.get("heal", 0)
                    enemy.hp = min(enemy.hp + heal, enemy.maxhp)
                    print(f"Геласий и Арейя восстановили {heal} HP!")
                    enemy_tokens -= 1
                    continue

                hit_chance = self._calc_hit_chance(
                    enemy.stats.get("ТОЧ", 0),
                    character.get_effective_stat("ТОЧ")
                )
                if random.random() > hit_chance:
                    print("Геласий и Арейя промахнулись!")
                    enemy_tokens -= 1
                    continue

                damage = self._compute_enemy_damage(skill, enemy)
                crit_chance = self._calc_crit_chance(
                    enemy.stats.get("УДЧ", 0),
                    character.get_effective_stat("УДЧ")
                )
                if random.random() < crit_chance:
                    is_crit = True
                    damage = int(damage * 1.5)
                    print("Критический удар врага!")

                damage = self._apply_defense(damage, character.get_effective_stat("ЗАЩ"))
                character.hp -= damage
                print(f"Геласий и Арейя наносят {damage} урона!")
                if skill.get("effect"):
                    print(f"На {character.name} наложен эффект: {skill['effect']}")
                weak_hit = self._is_weak_hit_on_player(skill)

                if weak_hit or is_crit:
                    enemy_tokens -= 0.5
                else:
                    enemy_tokens -= 1

            if character.hp <= 0 or enemy.hp <= 0:
                break

            playerturn = 3

        # Очистка дебаффа если бой закончился пока он активен
        if active_debuff:
            character.stats[active_debuff["stat"]] += active_debuff["amount"]
        if active_buff:
            enemy.stats[active_buff["stat"]] -= active_buff["bonus"]

        if character.hp <= 0:
            print(f"\n{character.name} пал в битве с Геласием и Арейей...")
            self._on_player_death()
        else:
            print(f"\n*Существо распадается на два силуэта... Геласий и Арейя падают.*")
            character.add_exp(enemy.give_exp)
            character.souls += getattr(enemy, "give_souls", 0)
            print(f"Получено: {enemy.give_exp} опыта, {getattr(enemy, 'give_souls', 0)} душ.")
            # Запускаем сцену побега Геласия через объект Game
            import game as game_module
            g = getattr(game_module, "game", None)
            if g and hasattr(g, "Gelasi_fleeing"):
                g.Gelasi_fleeing()


# ---------------------------------------------------------------------------
# Scripted cinematic beats for the final rooftop fight (no RNG)
# ---------------------------------------------------------------------------
_SCRIPTED_BEATS = [
    # (speaker, line, player_dmg_to_enemy, enemy_dmg_to_player)
    ("narr",   "*Кровь капает с вашего плеча на камни крыши... Геласий стоит перед вами, дышит тяжело, кулаки сжаты.*", 0, 0),
    ("gelasi", "'Устал?! Я тоже! Но это не закончится, пока один из нас не упадёт!'", 0, 0),
    ("narr",   "*Он бросается на вас — прямой удар в грудь.*", 0, 18),
    ("sin",    "*Вы уходите в сторону и врезаете ему локтем по рёбрам.*", 22, 0),
    ("narr",   "*Геласий хрипит, но не отступает. Он хватает вас за плечо — прямо за рану от кинжала.*", 0, 25),
    ("sin",    "*Боль ослепляет на секунду. Вы стискиваете зубы и бьёте его в подбородок.*", 28, 0),
    ("gelasi", "'Ты не понимаешь... Тартар УМИРАЕТ. Всё, что я делал — ради этого!'", 0, 0),
    ("sin",    "*Вы молчите. Удар в живот.*", 20, 0),
    ("narr",   "*Геласий сгибается, но рычит и толкает вас к краю крыши.*", 0, 15),
    ("narr",   "*Вы чудом хватаетесь за выступ. Камень крошится под пальцами.*", 0, 0),
    ("gelasi", "'...Упади уже.' *Он смотрит на вас сверху вниз, тяжело дыша.*", 0, 0),
    ("sin",    "*Вы подтягиваетесь, разворачиваетесь — и бьёте его ногой в колено.*", 30, 0),
    ("narr",   "*Он падает на одно колено. Наконец — колено касается камня.*", 0, 0),
    ("gelasi", "'Нет... Нет!' *Он пытается встать — нога не держит.*", 0, 0),
    ("sin",    "*Вы налетаете на него сверху, прижимая к крыше. Удар. Ещё. Ещё.*", 35, 0),
    ("narr",   "*Геласий больше не сопротивляется. Руки падают.*", 0, 0),
    ("gelasi", "'...Хватит.' *Едва слышно.* '...Я проиграл.'", 0, 0),
    ("narr",   "*Вы стоите на коленях над ним. Кулаки разбиты. Дышать больно.*", 0, 0),
    ("narr",   "*Тишина. Только ветер над крышей.*", 0, 0),
]


class scripted_final_battle:
    """Полностью скриптованный финальный бой на крыше. Без крит/промахов."""

    def run(self):
        character = ch_module.character
        # Геласий без слияния — только он сам, ослабленный после побега
        gelasi_hp = 80
        gelasi_name = "Геласий"

        print("\n" + "═" * 50)
        print("  ФИНАЛЬНЫЙ БОЙ")
        print("═" * 50)
        print(f"\nHP Сина:    {character.hp}/{character.maxhp}")
        print(f"HP Геласия: {gelasi_hp}")
        input("\n[Нажмите Enter, чтобы начать...]\n")

        for speaker, line, p_dmg, e_dmg in _SCRIPTED_BEATS:
            # Нанести урон прежде чем напечатать результат строки
            if e_dmg > 0:
                character.hp = max(1, character.hp - e_dmg)  # Син не умирает в скриптованной сцене
            if p_dmg > 0:
                gelasi_hp = max(0, gelasi_hp - p_dmg)

            # Вывод строки с префиксом
            if speaker == "narr":
                print(f"\n{line}")
            elif speaker == "gelasi":
                print(f"\n  {line}")
            else:  # sin / player action
                print(f"\n  {line}")

            # Показать состояние HP после урона
            if p_dmg > 0 or e_dmg > 0:
                print(f"    [ HP Сина: {character.hp}/{character.maxhp}  |  HP Геласия: {gelasi_hp} ]")

            input("  [Enter] ")

            if gelasi_hp <= 0:
                break

        # Финал — Геласий на земле
        print("\n" + "─" * 50)
        print("*Геласий лежит на камне. Глаза открыты — смотрит в небо.*")
        print("*Вы над ним. Кулак занесён.*")
        print("*Но больше не нужно.*")
        print("─" * 50 + "\n")
        input("[Enter] ")
        
