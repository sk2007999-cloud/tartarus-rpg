import random

from data import (
    ALLskills, ALL_WEAPONS,
    MAKOTO_SKILLS,
    ENEMY_SKILLS, LIONTUTORIAL_SKILLS, RED_LEOPARD_SKILLS,
    BLUE_LEOPARD_SKILLS, MINOTAUR_SKILLS, TITAN_KOI_SKILLS, GELASI_SKILLS,
    SOLDIER_SKILLS, COMMANDER_SKILLS,
    SKILL_STONE_MAP,
)


class Character:
    def __init__(self, skill_ids=None, ng_plus_stats=None):
        self.name = "???"          # когда аид базарит, можно будет спросить имя и записать его сюда
        self.hp = 100
        self.sp = 20
        self.maxhp = 100
        self.maxsp = 20
        self.exp = 0
        self.maxexp = 20
        self.level = 1
        # Start with only Attack; other skills come from skill stones
        self.skill_ids = list(skill_ids) if skill_ids else ["1"]
        self.skills = {sid: ALLskills[sid] for sid in self.skill_ids}
        self.stats = {"СИЛ": 2, "МАГ": 2, "ЗАЩ": 2, "ТОЧ": 2, "УДЧ": 2}

        # NG+ stats override if provided
        if ng_plus_stats:
            for k, v in ng_plus_stats.items():
                if k in self.stats:
                    self.stats[k] = v

        # эээ, эти аффинити к стихиям, которые влияют на урон от навыков и оружия, тоже будут задаваться амулетом после сцены с аидом
        # по умолчанию 1, а при выборе стихии в амулете будет 1.5 для выбранной и 0.5 для противоположной
        self.IncFireDMG  = 1
        self.IncIceDMG   = 1
        self.IncElecDMG  = 1
        self.IncLightDMG = 1
        self.IncDarkDMG  = 1

        self.inventory    = []
        self.souls        = 0
        self.equipped_weapon = None
        self.stat_points  = 0

    # ------------------------------------------------------------------
    def get_effective_stat(self, stat_name):
        val = self.stats.get(stat_name, 0)
        if self.equipped_weapon and self.equipped_weapon in ALL_WEAPONS:
            val += ALL_WEAPONS[self.equipped_weapon].get("stat_bonus", {}).get(stat_name, 0)
        return val

    def get_weapon_damage_bonus(self):
        if self.equipped_weapon and self.equipped_weapon in ALL_WEAPONS:
            return ALL_WEAPONS[self.equipped_weapon].get("damage_bonus", 0)
        return 0

    def get_skill_by_name(self, name):
        for skill_id, skill in self.skills.items():
            if skill["name"].lower() == name.lower():
                return skill_id, skill
        return None, None

    def can_use_skill(self, skill_id):
        if skill_id not in self.skills:
            return False
        skill = self.skills[skill_id]
        if skill.get("costhp", 0) > self.hp:
            return False
        if skill.get("costsp", 0) > self.sp:
            return False
        return True

    def add_skill(self, skill_id):
        """Добавляет навык персонажу, если его ещё нет и он существует в ALLskills."""
        if skill_id in self.skill_ids:
            return False
        if skill_id not in ALLskills:
            return False
        self.skill_ids.append(skill_id)
        self.skills[skill_id] = ALLskills[skill_id]
        return True

    def add_exp(self, amount):
        self.exp += amount
        while self.exp >= self.maxexp:
            self.exp -= self.maxexp
            self.level += 1
            self.maxexp = int(self.maxexp * 1.5)
            self.maxhp += 20
            self.maxsp += 10
            self.hp = self.maxhp
            self.sp = self.maxsp
            self.stat_points += 1
            print("Вы достигли нового уровня!")
            print(f"Теперь вы {self.level} уровня!")
            print("Максимальное HP и SP увеличены!")
            print(f"У вас теперь {self.stat_points} нераспределённых очков характеристик.")

    def set_affinities_from_amulet(self, fire, ice, elec, light, dark):
        """Устанавливает аффинити к стихиям, которые влияют на урон от навыков и оружия."""
        self.IncFireDMG  = fire
        self.IncIceDMG   = ice
        self.IncElecDMG  = elec
        self.IncLightDMG = light
        self.IncDarkDMG  = dark

    def set_skills_from_amulet(self, skill_ids):
        """Устанавливает навыки персонажа в соответствии с выбранными камнями навыков в амулете."""
        for sid in skill_ids:
            self.add_skill(sid)


class enemystats:
    def __init__(self, name, hp, sp, skill_ids, inc_firedmg, inc_icedmg, inc_elecdmg,
                 inc_lightdmg, inc_darkdmg, str_stat, mag_stat, def_stat, agil_stat,
                 luck_stat, give_exp, give_souls=0):
        self.name = name
        self.hp = hp
        self.sp = sp
        self.maxhp = hp
        self.maxsp = sp
        self.str_strat = str_stat
        self.skill_ids = skill_ids
        self.skills = {sid: ALLskills[sid] for sid in skill_ids}
        self.IncFireDMG  = inc_firedmg
        self.IncIceDMG   = inc_icedmg
        self.IncElecDMG  = inc_elecdmg
        self.IncLightDMG = inc_lightdmg
        self.IncDarkDMG  = inc_darkdmg
        self.stats = {
            "СИЛ": str_stat, "МАГ": mag_stat,
            "ЗАЩ": def_stat, "ТОЧ": agil_stat, "УДЧ": luck_stat,
        }
        self.give_exp   = give_exp
        self.give_souls = give_souls

    def can_use_skill(self, skill_id):
        if skill_id not in self.skills:
            return False
        skill = self.skills[skill_id]
        if skill.get("costhp", 0) > self.hp:
            return False
        if skill.get("costsp", 0) > self.sp:
            return False
        return True

    def get_random_skill(self):
        available = [sid for sid in self.skill_ids if self.can_use_skill(sid)]
        return random.choice(available) if available else None


# ---------------------------------------------------------------------------
# тут все статы персов, вот игрок
# ---------------------------------------------------------------------------
character = Character(MAKOTO_SKILLS)

# ---------------------------------------------------------------------------
# тутоооо враги, их статы, навыки и т.д., по дефолту для обучения лев, остальные для рандомных встреч и основных боссов
# ---------------------------------------------------------------------------
tutorial_enemy_lion = enemystats("Лев",            40,  20, LIONTUTORIAL_SKILLS, 2, 1, 0.5, 1, 1,  5,  5,  5, 5, 5,  50,  0)
enemy_placeholder1  = enemystats("Ящерица",         80,  20, ENEMY_SKILLS,        1, 2, 1,   1, 1,  3,  5,  5, 5, 5,  40,  10)
enemy_placeholder2  = enemystats("Демон-Они",   100,  10, ENEMY_SKILLS,        1, 1, 2,   1, 1,  7,  5,  5, 5, 5,  60,  10)
enemy_placeholder3  = enemystats("Демон-Гидра",    90,  25, ENEMY_SKILLS,        2, 1, 1,   1, 1,  4,  5,  5, 5, 5,  45,  10)
enemy_placeholder4  = enemystats("Лягушка",    70,  35, ENEMY_SKILLS,        1, 1, 1,   2, 1,  2,  5,  5, 5, 5,  35,  10)
red_leopard         = enemystats("Красный леопард",75,  40, RED_LEOPARD_SKILLS,  1.5,1.5,1.5,1, 1,  4,  7,  5, 6, 5,  80,  40)
blue_leopard        = enemystats("Синий леопард",  75,  25, BLUE_LEOPARD_SKILLS, 1,  1,  1,  1, 1,  7,  4,  6, 5, 5,  80,  30)
minotaur            = enemystats("Минотавр",        200,  50, MINOTAUR_SKILLS,    1,  1,  1,  1, 1,  9,  6,  8, 6, 5,   0,  300)
titan_koi           = enemystats("Титан Кой",       260,  70, TITAN_KOI_SKILLS,   1,  1,  1,  1, 1, 10,  8, 10, 6, 4, 250, 100)
gelassi             = enemystats("Геласий и Арейя", 350, 150, GELASI_SKILLS,      1,  2,  1,  1, 1, 10,  9, 10, 7, 6, 500, 50)
soldier             = enemystats("Солдат",           90,  20, SOLDIER_SKILLS,     1,  1,  1,  1, 1,  6,  4,  5, 5, 4,  60,  10)
commander           = enemystats("Коммандир",       200,  50, COMMANDER_SKILLS,   1,  1,  2,  1, 1,  8,  6,  7, 6, 5, 200, 20)

RANDOM_ENEMIES  = [enemy_placeholder1, enemy_placeholder2, enemy_placeholder3, enemy_placeholder4]
CHURCH_SOLDIERS = [soldier]

# Current enemy (default for tutorial)
enemy         = tutorial_enemy_lion
tutorial_enemy = tutorial_enemy_lion

# ---------------------------------------------------------------------------
# хз че тут писать тут все понятно
# ---------------------------------------------------------------------------
playerturn   = 3
enemyturn    = 3
tutorial_battle_state     = False
random_battle_state       = False
quest_monster_bridge_completed = False
monster_on_bridge         = True
