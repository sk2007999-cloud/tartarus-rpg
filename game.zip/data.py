'''ВСЕ СКИЛЛЫ'''
ALLskills = {
#физические атаки
"1":  {"name": "Атака",               "type": "Физический",    "damage":10,  "costhp":0,  "costsp":0},
"2":  {"name": "Удар иглой",          "type": "Физический",    "damage":30,  "costhp":12, "costsp":0, "effect":"Страх"},
"3":  {"name": "Устрашающая улыбка",  "type": "Физический",    "damage":70,  "costhp":12, "costsp":0, "specialeffectuse":"Страх", "specialdamage":9999},
#огненные
"4":  {"name": "Фотия",               "type": "Огонь",          "damage":10,  "costhp":0,  "costsp": 6},
"5":  {"name": "Фотияно",            "type": "Огонь",          "damage":20,  "costhp":0,  "costsp": 12},
"6":  {"name": "Фотиямано",          "type": "Огонь",          "damage":30,  "costhp":0,  "costsp": 18},
#электрические
"7":  {"name": "Астрапи",            "type": "Электричество",  "damage":10,  "costhp":0,  "costsp": 6},
"8":  {"name": "Астрапино",          "type": "Электричество",  "damage":20,  "costhp":0,  "costsp": 12},
"9":  {"name": "Астрапимано",        "type": "Электричество",  "damage":30,  "costhp":0,  "costsp": 18},
#лед
"10": {"name": "Пагос",              "type": "Лед",             "damage":10,  "costhp":0,  "costsp": 6},
"11": {"name": "Пагосин",            "type": "Лед",             "damage":20,  "costhp":0,  "costsp": 12},
"12": {"name": "Пагосиман",          "type": "Лед",             "damage":30,  "costhp":0,  "costsp": 18},
#баффы
"13": {"name": "Эпитехси",           "type": "Бафф",           "damage":0,   "costhp":0,  "costsp":8,  "effect":"Атака"},
"14": {"name": "Упэкфиги",           "type": "Бафф",           "damage":0,   "costhp":0,  "costsp":8,  "effect":"Уклонение"},
"15": {"name": "Простасия",          "type": "Бафф",           "damage":0,   "costhp":0,  "costsp":8,  "effect":"Защита"},
#лечение
"16": {"name": "Зои",                "type": "Востановление",  "heal":30,    "costsp":6},
"17": {"name": "Мазои",              "type": "Востановление",  "heal":30,    "costsp":12},
"18": {"name": "Музазои",            "type": "Востановление",  "heal":30,    "costsp":6},
#phys2
"19": {"name": "Череполом",          "type": "Физический",     "damage":40,  "costhp":22, "costsp":0},
"20": {"name": "Глубокий порез",     "type": "Физический",     "damage":30,  "costhp":12, "costsp":0},
}

# ---------------------------------------------------------------------------
# Камни умений: stone_item_id -> skill_id
# ---------------------------------------------------------------------------
SKILL_STONE_MAP = {
    "attack_stone":      "1",
    "needle_stone":      "2",
    "smile_stone":       "3",
    "fotia_stone":       "4",
    "fotiiano_stone":    "5",
    "fotiamano_stone":   "6",
    "astrapi_stone":     "7",
    "astrapino_stone":   "8",
    "astrapimano_stone": "9",
    "pagos_stone":       "10",
    "pagosin_stone":     "11",
    "pagosiman_stone":   "12",
    "epitehsi_stone":    "13",
    "upekfigi_stone":    "14",
    "prostasia_stone":   "15",
    "zoi_stone":         "16",
    "mazoi_stone":       "17",
    "muzazoi_stone":     "18",
    "cherepol_stone":    "19",
    "deepcut_stone":     "20",
}

'''ВСЕ ПРЕДМЕТЫ'''
ALL_ITEMS = {
    # --- расходники ---
    "bread":             {"name": "Хлеб",                        "price": 3,  "effect": "heal",        "heal_amount": 30},
    "pass":              {"name": "Пропуск"},
    "health_potion":     {"name": "Зелье здоровья",              "price": 10, "effect": "heal",        "heal_amount": 50},
    "mana_potion":       {"name": "Зелье маны",                  "price": 10, "effect": "mana",        "mana_amount": 15},
    "str_potion":        {"name": "Зелье силы",                  "price": 10, "effect": "stat",        "stat": "СИЛ", "amount": 1},
    "agl_potion":        {"name": "Зелье ловкости",              "price": 10, "effect": "stat",        "stat": "ТОЧ", "amount": 1},
    "int_potion":        {"name": "Зелье интеллекта",            "price": 10, "effect": "stat",        "stat": "МАГ", "amount": 1},
    "lck_potion":        {"name": "Зелье харизмы",               "price": 10, "effect": "stat",        "stat": "УДЧ", "amount": 1},
    "gorgon_head":       {"name": "Голова Медузы",               "effect": "gorgon"},
    "gate_key":          {"name": "Ключ от ворот",               "effect": "key"},
    # --- камни умений ---
    "attack_stone":      {"name": "Камень: Атака",               "price": 5,  "effect": "skill_stone"},
    "needle_stone":      {"name": "Камень: Удар иглой",          "price": 10, "effect": "skill_stone"},
    "smile_stone":       {"name": "Камень: Устрашающая улыбка",  "price": 20, "effect": "skill_stone"},
    "fotia_stone":       {"name": "Камень: Фотия",               "price": 8,  "effect": "skill_stone"},
    "fotiiano_stone":    {"name": "Камень: Фотияно",             "price": 14, "effect": "skill_stone"},
    "fotiamano_stone":   {"name": "Камень: Фотиямано",           "price": 20, "effect": "skill_stone"},
    "astrapi_stone":     {"name": "Камень: Астрапи",             "price": 8,  "effect": "skill_stone"},
    "astrapino_stone":   {"name": "Камень: Астрапино",           "price": 14, "effect": "skill_stone"},
    "astrapimano_stone": {"name": "Камень: Астрапимано",         "price": 20, "effect": "skill_stone"},
    "pagos_stone":       {"name": "Камень: Пагос",               "price": 8,  "effect": "skill_stone"},
    "pagosin_stone":     {"name": "Камень: Пагосин",             "price": 14, "effect": "skill_stone"},
    "pagosiman_stone":   {"name": "Камень: Пагосиман",           "price": 20, "effect": "skill_stone"},
    "epitehsi_stone":    {"name": "Камень: Эпитехси",            "price": 12, "effect": "skill_stone"},
    "upekfigi_stone":    {"name": "Камень: Упэкфиги",            "price": 12, "effect": "skill_stone"},
    "prostasia_stone":   {"name": "Камень: Простасия",           "price": 12, "effect": "skill_stone"},
    "zoi_stone":         {"name": "Камень: Зои",                 "price": 10, "effect": "skill_stone"},
    "mazoi_stone":       {"name": "Камень: Мазои",               "price": 16, "effect": "skill_stone"},
    "muzazoi_stone":     {"name": "Камень: Музазои",             "price": 10, "effect": "skill_stone"},
    "cherepol_stone":    {"name": "Камень: Череполом",           "price": 16, "effect": "skill_stone"},
    "deepcut_stone":     {"name": "Камень: Глубокий порез",      "price": 12, "effect": "skill_stone"},
}

'''ВСЕ ОРУЖИЯ'''
ALL_WEAPONS = {
    "greatsword":  {"name": "Большой меч", "damage_bonus": 15, "stat_bonus": {"СИЛ": 2}, "price": 25},
    "saber":       {"name": "Сабля",        "damage_bonus": 8,  "stat_bonus": {"УДЧ": 3}, "price": 18},
    "staff":       {"name": "Посох",        "damage_bonus": 5,  "stat_bonus": {"МАГ": 2}, "price": 15},
    "dagger":      {"name": "Кинжал",       "damage_bonus": 6,  "stat_bonus": {"ТОЧ": 2}, "price": 12},
    "mace":        {"name": "Булава",       "damage_bonus": 12, "stat_bonus": {"СИЛ": 1, "ЗАЩ": 1}, "price": 20},
    "rapier":      {"name": "Рапира",       "damage_bonus": 7,  "stat_bonus": {"ТОЧ": 1, "УДЧ": 1}, "price": 16},
    "katana":      {"name": "Катана",       "damage_bonus": 20, "stat_bonus": {"УДЧ": 4}},
    "bow":         {"name": "Лук",          "damage_bonus": 13, "stat_bonus": {"ТОЧ": 4}},
    "executioner": {"name": "Палач",        "damage_bonus": 40, "stat_bonus": {"СИЛ": 5}},
}

# ---------------------------------------------------------------------------
# Конфигурация лавки Айвора по номеру визита
# ---------------------------------------------------------------------------
AIVOR_VISIT_1_ITEMS   = ["bread"]
AIVOR_VISIT_1_WEAPONS = []
AIVOR_VISIT_1_STONES  = []

AIVOR_VISIT_2_ITEMS   = ["bread", "health_potion", "mana_potion", "str_potion", "agl_potion"]
AIVOR_VISIT_2_WEAPONS = ["dagger", "saber", "mace"]
AIVOR_VISIT_2_STONES  = ["fotia_stone", "astrapi_stone", "pagos_stone",
                          "needle_stone", "zoi_stone", "epitehsi_stone", "upekfigi_stone"]

AIVOR_VISIT_3_ITEMS   = ["bread", "health_potion", "mana_potion",
                          "str_potion", "agl_potion", "int_potion", "lck_potion"]
AIVOR_VISIT_3_WEAPONS = ["dagger", "saber", "greatsword", "staff", "mace", "rapier", "bow", "executioner"]
AIVOR_VISIT_3_STONES  = [k for k in ALL_ITEMS if ALL_ITEMS[k].get("effect") == "skill_stone"]

# Legacy (unused but kept for any old save compat)
STORE_ITEMS_BY_ZONE   = {}
STORE_ITEMS_DEFAULT   = AIVOR_VISIT_3_ITEMS
STORE_WEAPONS_BY_ZONE = {}
STORE_WEAPONS_DEFAULT = AIVOR_VISIT_3_WEAPONS

# ---------------------------------------------------------------------------
# Списки умений
# ---------------------------------------------------------------------------
# Игрок начинает ТОЛЬКО с Атаки — остальное через камни умений
MAKOTO_SKILLS = ["1"]

ENEMY_SKILLS        = ["1", "10"]
LIONTUTORIAL_SKILLS = ["1", "10"]
RED_LEOPARD_SKILLS  = ["1", "4", "10"]
BLUE_LEOPARD_SKILLS = ["1", "2"]
MINOTAUR_SKILLS     = ["19"]
TITAN_KOI_SKILLS    = ["19", "5", "11"]
GELASI_SKILLS       = ["1", "5", "8", "11", "13", "14", "15"]
SOLDIER_SKILLS      = ["1", "2", "19"]
COMMANDER_SKILLS    = ["1", "19", "4", "15"]

MENU_ART = '''
           )
              /  )
             /  / )
        -   /  / / 
           '  / / -
          / _/ / /
    _    / _/_, /          ,
  + $$$ / _/_/_/          \\       |
/- + $$/ _/_/_/      / 
\\`_ $$/'_/_/    .    ______   _
   \\ (  / ___,_____ _ _____,
   |  `(|/_,_,__ ________/  
   |.   |''_,_______)       ______________
    \\   (_                 /______________\\ 
     \\  / |-._                   |  |
      \\.' /|/ \\_._               |  |
      /_/   _/    /-'__          |  |
        \\     \\ '      \\.___     |  |
         '.   /,     |_/_   |._  |  |   ________   \\________   ________  ________   \\________  _        _   _________
           \\ / )   '.     '_/, ) \\  |  |        |  |        /     ||    |        |  |        / |        |  \\
            (_(     -\\_   /  \\ \\  | |  |      / |  |              ||    |      / |  |          |        |    -------
               \\__      |-'   |/   \\|  |_____/  |  |              ||    |_____/  |  |          |________|\\  _______ /
                 \\._  /_/_
                    \\_/\\  )
                        \\ |
                        |/  
-------------
Действия:
      1. Начать игру сначала.
      2. Загрузить игру.
      3. Новая игра+ (амулет).
      4. Выйти из игры.
-------------
'''
