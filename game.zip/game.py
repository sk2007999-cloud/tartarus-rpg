import json
import random

from matplotlib.pylab import character

from data import (
    ALL_ITEMS, ALL_WEAPONS,
    AIVOR_VISIT_1_ITEMS, AIVOR_VISIT_1_WEAPONS, AIVOR_VISIT_1_STONES,
    AIVOR_VISIT_2_ITEMS, AIVOR_VISIT_2_WEAPONS, AIVOR_VISIT_2_STONES,
    AIVOR_VISIT_3_ITEMS, AIVOR_VISIT_3_WEAPONS, AIVOR_VISIT_3_STONES,
    SKILL_STONE_MAP,
    MENU_ART,
)
import characters as ch_module
from battle import battle

# Module-level reference to the active Game instance
game = None

# NG+ save file
NG_PLUS_FILE = "ng_plus_amulet.json"


class Game:
    def __init__(self, ng_plus_stats=None):
        self.zone           = "hades_intro"
        self.quest_rock     = False
        self.lion_soul      = True
        self.last_save_slot = None
        self.aivor_visits   = 0      # how many times Aivor has been visited

        # Reset shared state
        ch_module.tutorial_battle_state = False
        ch_module.playerturn = 3
        ch_module.enemyturn  = 3
        ch_module.quest_monster_bridge_completed = False
        ch_module.monster_on_bridge = True

        # Reset character (NG+ passes saved stats)
        from data import MAKOTO_SKILLS
        ch_module.character = ch_module.Character(MAKOTO_SKILLS, ng_plus_stats)

    # ------------------------------------------------------------------
    # тут играется, по сути, тут же и начинается, а дальше уже в зависимости от зоны вызываются функции из game.py, которые описывают эту зону и её события
    # ------------------------------------------------------------------
    def run(self):
        print("\n*Игра запущена.*")
        self.hades_intro()
        self.zone = "camera_zone"
        self.camera_zone()
        self.lion_soul = True
        ch_module.tutorial_battle_state = True
        ch_module.enemy = ch_module.tutorial_enemy_lion
        ch_module.enemy.hp  = ch_module.enemy.maxhp
        ch_module.playerturn = 3
        ch_module.enemyturn  = 3
        battle().start_tutorial_battle()
        ch_module.enemy.hp  = ch_module.enemy.maxhp
        ch_module.playerturn = 3
        ch_module.enemyturn  = 3
        self.zone = "corridor_zone"
        self.corridor_zone()
        self.zone = "old_man"
        self.old_man()
        self.zone = "river_zone"
        self._offer_save()
        self.river_zone()
        self.zone = "before_maze_zone"
        self.to_the_maze()
        self.zone = "maze_zone"
        self.maze_zone()
        self.zone = "medusa_zone"
        self.medusa_zone()

    # ------------------------------------------------------------------
    # интро с аидом
    # ------------------------------------------------------------------
    def hades_intro(self):
        self.zone = "hades_intro"
        character = ch_module.character
        print("\n*Вспышка. Темнота рассеивается — вы стоите перед огромными вратами.*")
        print("*Перед вами — высокий мужчина в тёмном плаще, с лёгкой улыбкой.*")
        print("'Хей! Наконец-то. Я уже думал, ты не появишься.' *Он смеётся.*")
        print("'Меня зовут Аид. Добро пожаловать в Тартар.'")
        print("'Прежде чем ты пойдёшь... мне нужно кое-что знать.'")
        print()

        # Name     
        
        print("*Аид приподнимает бровь.* 'Имя, пожалуйста.'")
        print("Напомни, как тебя зовут? А нет, я вспомнил...")
        character.name = "Син"

        print(f"\n'Отлично, та' *Аид кивает.*")
        print("'Теперь — твои стихии. В Тартаре не все атаки одинаково опасны.'")
        print("'Скажи мне: к чему ты склонен?'")
        print()
        print("Выберите слабость (стихия наносит вам двойной урон):")
        print("  1. Огонь   2. Лёд   3. Электричество   4. Нет слабости")
        weak_map = {"1": "fire", "2": "ice", "3": "elec",
                    "огонь": "fire", "лёд": "ice", "электричество": "elec"}
        weakness = None
        while True:
            w = input("> ").strip().lower()
            if w in weak_map:
                weakness = weak_map[w]
                break
            print("Введите 1, 2, или 3")

        print("Выберите сопротивление (стихия наносит вам половину урона):")
        print("  1. Огонь   2. Лёд   3. Электричество")
        resist = None
        while True:
            r = input("> ").strip().lower()
            if r in weak_map:
                resist = weak_map[r]
                break
            print("Введите 1, 2, или 3")

        fire  = 2 if weakness == "fire"  else (0.5 if resist == "fire"  else 1)
        ice   = 2 if weakness == "ice"   else (0.5 if resist == "ice"   else 1)
        elec  = 2 if weakness == "elec"  else (0.5 if resist == "elec"  else 1)
        character.set_affinities_from_amulet(fire, ice, elec, 1, 1)

        affinity_desc = []
        if weakness: affinity_desc.append(f"слабость: {['огонь','лёд','электричество'][['fire','ice','elec'].index(weakness)]}")
        if resist:   affinity_desc.append(f"сопротивление: {['огонь','лёд','электричество'][['fire','ice','elec'].index(resist)]}")
        desc_str = ", ".join(affinity_desc) if affinity_desc else "нейтральные стихии"

        print(f"\n*Аид достаёт из-за пазухи светящийся амулет.*")
        print(f"'Вот. Здесь хранятся твои умения и стихии. {desc_str.capitalize()}.'")
        print("'Амулет раскроет свои силы по мере того, как ты будешь использовать камни умений.'")
        print("'Пока в нём — только базовая Атака. Остальное — найдёшь сам.'")
        print("*Аид надевает амулет на вас.*")
        print(f"\n'Удачи. И постарайся не умереть сразу.' *Он усмехается и исчезает.*\n")
        input("[Нажмите Enter, чтобы продолжить...]\n")

    # ------------------------------------------------------------------
    # сохранки и лоуды, Я НЕНАВИЖУ ЭТОТ КОД
    # ------------------------------------------------------------------
    def _get_save_state(self):
        character = ch_module.character
        return {
            "zone":       self.zone,
            "quest_rock": getattr(self, "quest_rock", False),
            "lion_soul":  self.lion_soul,
            "aivor_visits": self.aivor_visits,
            "quest_monster_bridge_completed": ch_module.quest_monster_bridge_completed,
            "monster_on_bridge": ch_module.monster_on_bridge,
            "character": {
                "name":          character.name,
                "hp":            character.hp,
                "sp":            character.sp,
                "maxhp":         character.maxhp,
                "maxsp":         character.maxsp,
                "exp":           character.exp,
                "maxexp":        character.maxexp,
                "level":         character.level,
                "stats":         character.stats,
                "IncFireDMG":    character.IncFireDMG,
                "IncIceDMG":     character.IncIceDMG,
                "IncElecDMG":    character.IncElecDMG,
                "IncLightDMG":   character.IncLightDMG,
                "IncDarkDMG":    character.IncDarkDMG,
                "inventory":     character.inventory,
                "souls":         character.souls,
                "equipped_weapon": character.equipped_weapon,
                "stat_points":   character.stat_points,
                "skill_ids":     character.skill_ids,
            },
        }

    def _load_save_state(self, state):
        character = ch_module.character
        if not state:
            return
        self.zone         = state.get("zone", self.zone)
        self.quest_rock   = state.get("quest_rock", False)
        self.lion_soul    = state.get("lion_soul", True)
        self.aivor_visits = state.get("aivor_visits", 0)
        ch_module.quest_monster_bridge_completed = state.get("quest_monster_bridge_completed", False)
        ch_module.monster_on_bridge = state.get("monster_on_bridge", True)
        ch = state.get("character", {})
        character.name           = ch.get("name", character.name)
        character.hp             = ch.get("hp", character.hp)
        character.sp             = ch.get("sp", character.sp)
        character.maxhp          = ch.get("maxhp", character.maxhp)
        character.maxsp          = ch.get("maxsp", character.maxsp)
        character.exp            = ch.get("exp", character.exp)
        character.maxexp         = ch.get("maxexp", character.maxexp)
        character.level          = ch.get("level", character.level)
        character.stats          = ch.get("stats", character.stats)
        character.IncFireDMG     = ch.get("IncFireDMG", character.IncFireDMG)
        character.IncIceDMG      = ch.get("IncIceDMG", character.IncIceDMG)
        character.IncElecDMG     = ch.get("IncElecDMG", character.IncElecDMG)
        character.IncLightDMG    = ch.get("IncLightDMG", character.IncLightDMG)
        character.IncDarkDMG     = ch.get("IncDarkDMG", character.IncDarkDMG)
        character.inventory      = ch.get("inventory", character.inventory)
        character.souls          = ch.get("souls", character.souls)
        character.equipped_weapon = ch.get("equipped_weapon", character.equipped_weapon)
        character.stat_points    = ch.get("stat_points", character.stat_points)
        # Restore skills
        saved_skill_ids = ch.get("skill_ids", character.skill_ids)
        from data import ALLskills
        character.skill_ids = [sid for sid in saved_skill_ids if sid in ALLskills]
        character.skills    = {sid: ALLskills[sid] for sid in character.skill_ids}

    def _resume_from_zone(self):
        z = self.zone
        if z == "hades_intro":
            self.hades_intro(); self.camera_zone()
        elif z == "camera_zone":
            self.camera_zone()
        elif z == "corridor_zone":
            self.corridor_zone()
        elif z == "old_man":
            self.old_man()
        elif z == "river_zone":
            self.river_zone()
        elif z == "bridge_zone":
            self.bridge_zone()
        elif z == "before_maze_zone":
            self.to_the_maze()
        elif z == "maze_zone":
            self.maze_zone()
        elif z == "medusa_zone":
            self.medusa_zone()
        elif z == "church_zone":
            self.gelasi_church()
        elif z == "end":
            self.end()
        else:
            print(f"Неизвестная зона '{z}'. Возврат в начало.")
            self.camera_zone()

    def _offer_save(self):
        print("\n---Сохранение игры---")
        ans = input("Хотите сохранить игру? (y/n): ").strip().lower()
        if ans not in ("y", "yes", "д", "да"):
            return
        print("Выберите слот (1-3):")
        slot = input("> ").strip()
        if slot not in ("1", "2", "3"):
            print("Неверный слот.")
            return
        state    = self._get_save_state()
        filename = f"save_slot_{slot}.json"
        try:
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False, indent=2)
            self.last_save_slot = slot
            print(f"Игра сохранена в слот {slot}.")
        except Exception as e:
            print(f"Не удалось сохранить игру: {e}")

    def load_from_slot(self):
        """Load menu — loops until valid slot chosen or user exits."""
        while True:
            print("\n---Загрузка игры---")
            print("Выберите слот (1-3) или 0 для выхода:")
            slot = input("> ").strip()
            if slot == "0":
                print("Загрузка отменена.")
                return False
            if slot not in ("1", "2", "3"):
                print("Неверный слот. Введите 1, 2, 3 или 0 для выхода.")
                continue
            filename = f"save_slot_{slot}.json"
            try:
                with open(filename, "r", encoding="utf-8") as f:
                    state = json.load(f)
            except FileNotFoundError:
                print("В этом слоте ещё нет сохранения. Попробуйте другой или введите 0.")
                continue
            except Exception as e:
                print(f"Не удалось загрузить: {e}. Попробуйте другой слот или введите 0.")
                continue
            self._load_save_state(state)
            self.last_save_slot = slot
            print(f"Игра загружена из слота {slot}. Текущая зона: {self.zone}.")
            self._resume_from_zone()
            return True

    def load_last_save_after_death(self):
        if not self.last_save_slot:
            print("\nНет сохранённых игр. Игра окончена.")
            return
        slot = self.last_save_slot
        print(f"\nВы погибли. Загрузить последнее сохранение (слот {slot})? (y/n)")
        ans = input("> ").strip().lower()
        if ans not in ("y", "yes", "д", "да"):
            print("Игра окончена.")
            return
        filename = f"save_slot_{slot}.json"
        try:
            with open(filename, "r", encoding="utf-8") as f:
                state = json.load(f)
        except Exception as e:
            print(f"Не удалось загрузить: {e}")
            return
        self._load_save_state(state)
        print(f"Сохранение загружено из слота {slot}. Зона: {self.zone}.")
        self._resume_from_zone()

    # ------------------------------------------------------------------
    # эт для юай
    # ------------------------------------------------------------------
    def _print_stats(self):
        character = ch_module.character
        print("\n---Статистика персонажа---")
        print(f"Имя: {character.name}  |  Уровень: {character.level}  |  Опыт: {character.exp}/{character.maxexp}")
        print(f"HP= {character.hp}/{character.maxhp}   SP= {character.sp}/{character.maxsp}")
        ew   = character.equipped_weapon
        weap = ALL_WEAPONS.get(ew, {}).get("name", "нет") if ew else "нет"
        print(f"Оружие: {weap}")
        for k in ("СИЛ", "МАГ", "ЗАЩ", "ТОЧ", "УДЧ"):
            v = character.get_effective_stat(k)
            b = f" (+{v - character.stats[k]})" if ew and v > character.stats[k] else ""
            print(f"  {k}= {v}{b}")
        aff_lines = []
        names = {"IncFireDMG": "Огонь", "IncIceDMG": "Лёд", "IncElecDMG": "Электричество"}
        for attr, label in names.items():
            val = getattr(character, attr)
            if val == 2:   aff_lines.append(f"  СЛАБОСТЬ: {label}")
            elif val == 0.5: aff_lines.append(f"  СОПРОТ.: {label}")
        if aff_lines:
            print("Стихийные аффинити:")
            for l in aff_lines: print(l)
        print("\n---Умения---")
        for sid in character.skill_ids:
            sk = character.skills[sid]
            cost = ""
            if sk.get("costhp", 0): cost += f" -{sk['costhp']}HP"
            if sk.get("costsp", 0): cost += f" -{sk['costsp']}SP"
            print(f"  {sk['name']} ({sk['type']}, урон {sk.get('damage',0)}, лечение {sk.get('heal',0)}){cost}")
        if character.stat_points > 0:
            print(f"\nУ вас {character.stat_points} нераспределённых очков характеристик.")
            self._spend_stat_points()

    def _show_inventory(self):
        character = ch_module.character
        print("\n---Инвентарь---")
        items_only = [item for item in character.inventory if item not in ALL_WEAPONS]
        if items_only:
            for idx, item_id in enumerate(items_only, start=1):
                name = ALL_ITEMS.get(item_id, {}).get("name") or item_id
                print(f"  {idx}. {name}")
            print("\nИспользовать предмет? Введите номер или 0 для выхода.")
            choice = input("> ").strip()
            try:
                idx = int(choice)
                if 1 <= idx <= len(items_only):
                    self._use_item_outside_battle(items_only[idx - 1])
            except ValueError:
                pass
        else:
            print("Инвентарь пуст.")
        ew = character.equipped_weapon
        if ew and ew in ALL_WEAPONS:
            print(f"\nЭкипировано: {ALL_WEAPONS[ew]['name']}")

    def _use_item_outside_battle(self, item_id):
        """Use a consumable or skill stone from inventory outside of battle."""
        character = ch_module.character
        item = ALL_ITEMS.get(item_id, {})
        effect = item.get("effect")
        if effect == "heal":
            heal = item.get("heal_amount", 30)
            old  = character.hp
            character.hp = min(character.hp + heal, character.maxhp)
            print(f"Вы использовали {item['name']} и восстановили {character.hp - old} HP.")
            character.inventory.remove(item_id)
        elif effect == "mana":
            sp = item.get("mana_amount", 15)
            old = character.sp
            character.sp = min(character.sp + sp, character.maxsp)
            print(f"Вы использовали {item['name']} и восстановили {character.sp - old} SP.")
            character.inventory.remove(item_id)
        elif effect == "stat":
            stat   = item.get("stat")
            amount = item.get("amount", 1)
            if stat in character.stats:
                character.stats[stat] += amount
                print(f"{item['name']} использован. {stat} увеличена на {amount}.")
            character.inventory.remove(item_id)
        elif effect == "skill_stone":
            skill_id = SKILL_STONE_MAP.get(item_id)
            if skill_id:
                added = character.add_skill(skill_id)
                if added:
                    from data import ALLskills
                    print(f"*Камень рассыпается в свет... Умение «{ALLskills[skill_id]['name']}» изучено!*")
                else:
                    print(f"Умение «{ALL_ITEMS[item_id]['name'].replace('Камень: ','')}» уже известно.")
                character.inventory.remove(item_id)
            else:
                print("Этот камень не распознан.")
        else:
            print(f"{item.get('name', item_id)} нельзя использовать здесь.")

    def _spend_stat_points(self):
        character = ch_module.character
        while character.stat_points > 0:
            print(f"\nУ вас {character.stat_points} очко(а) характеристик.")
            for sk, sn in [("СИЛ","Сила"),("МАГ","Магия"),("ЗАЩ","Защита"),("ТОЧ","Точность"),("УДЧ","Удача")]:
                print(f"  {sk} ({sn}) — {character.stats[sk]}")
            print("Введите код характеристики или 'выход':")
            ch = input("> ").strip().upper()
            if ch in ("ВЫХОД", "НАЗАД", "0"):
                break
            if ch not in character.stats:
                print("Такой характеристики нет.")
                continue
            character.stats[ch] += 1
            character.stat_points -= 1
            print(f"{ch} увеличена до {character.stats[ch]}.")

    def _equip_weapon(self):
        character = ch_module.character
        weapons_in_inv = [(i, w) for i, w in enumerate(character.inventory, start=1) if w in ALL_WEAPONS]
        ew = character.equipped_weapon
        print("\n---Экипировка оружия---")
        print(f"Сейчас экипировано: {ALL_WEAPONS.get(ew, {}).get('name','нет') if ew else 'нет'}")
        if not weapons_in_inv:
            print("В инвентаре нет оружия.")
            return
        for num, wid in weapons_in_inv:
            w    = ALL_WEAPONS[wid]
            mark = " ✓" if wid == ew else ""
            print(f"  {num}. {w['name']} (+{w.get('damage_bonus',0)} урон, {w.get('stat_bonus',{})}){mark}")
        print("  0. Снять оружие.")
        try:
            idx = int(input("> ").strip())
        except ValueError:
            return
        if idx == 0:
            character.equipped_weapon = None
            print("Оружие снято.")
            return
        n2w = {n: w for n, w in weapons_in_inv}
        if idx in n2w:
            character.equipped_weapon = n2w[idx]
            print(f"Экипировано: {ALL_WEAPONS[character.equipped_weapon]['name']}")
        else:
            print("Такого оружия нет.")

    # ------------------------------------------------------------------
    # айвор
    # ------------------------------------------------------------------
    def store(self):
        """Open Aivor's shop for the current visit number."""
        character   = ch_module.character
        visit       = self.aivor_visits

        if visit == 1:
            item_ids   = AIVOR_VISIT_1_ITEMS
            weapon_ids = AIVOR_VISIT_1_WEAPONS
            stone_ids  = AIVOR_VISIT_1_STONES
        elif visit == 2:
            item_ids   = AIVOR_VISIT_2_ITEMS
            weapon_ids = AIVOR_VISIT_2_WEAPONS
            stone_ids  = AIVOR_VISIT_2_STONES
        else:
            item_ids   = AIVOR_VISIT_3_ITEMS
            weapon_ids = AIVOR_VISIT_3_WEAPONS
            stone_ids  = AIVOR_VISIT_3_STONES

        # Build menu
        available = {}
        idx = 1
        for aid in item_ids:
            if aid in ALL_ITEMS:
                available[idx] = ("item", aid, ALL_ITEMS[aid])
                idx += 1
        for wid in weapon_ids:
            if wid in ALL_WEAPONS:
                available[idx] = ("weapon", wid, ALL_WEAPONS[wid])
                idx += 1
        for sid in stone_ids:
            if sid in ALL_ITEMS:
                available[idx] = ("item", sid, ALL_ITEMS[sid])
                idx += 1

        while True:
            print("\n---Лавка Айвора---")
            print(f"У вас {character.souls} душ.")
            for num, (typ, tid, thing) in sorted(available.items()):
                price = thing.get("price", 0)
                tag   = "[ОРУЖИЕ] " if typ == "weapon" else ""
                already = " (уже в инвентаре)" if tid in character.inventory or tid == character.equipped_weapon else ""
                print(f"  {num}. {tag}{thing['name']} — {price} душ{already}")
            print("  0. Выйти из магазина.")
            choice = input("Что хотите купить?: ").strip()
            if choice in ("0", "выход", "назад"):
                break
            try:
                num = int(choice)
            except ValueError:
                print("Неверный ввод.")
                continue
            if num not in available:
                print("Такого товара нет.")
                continue
            typ, thing_id, thing = available[num]
            price = thing.get("price", 0)
            if character.souls < price:
                print("Недостаточно душ.")
                continue
            character.souls -= price
            character.inventory.append(thing_id)
            print(f"Вы купили {thing['name']}.")
            if thing.get("effect") == "skill_stone":
                print("(Используйте камень из инвентаря, чтобы выучить умение.)")

    # ------------------------------------------------------------------
    # случайные враги
    # ------------------------------------------------------------------
    def _maybe_random_encounter_river(self, chance: float = 0.2):
        if self.zone != "river_zone" or not ch_module.RANDOM_ENEMIES:
            return
        if random.random() >= chance:
            return
        print("*Враги напали!*")
        ch_module.enemy    = random.choice(ch_module.RANDOM_ENEMIES)
        ch_module.enemy.hp = ch_module.enemy.maxhp
        ch_module.enemy.sp = ch_module.enemy.maxsp
        ch_module.playerturn = 3
        ch_module.enemyturn  = 3
        battle().start_battle()

    def _maybe_random_encounter_church(self, chance: float = 0.2, _unused=True):
        if not ch_module.CHURCH_SOLDIERS:
            return
        if random.random() >= chance:
            return
        print("\n*Один из патрульных заметил вас!*")
        ch_module.enemy    = random.choice(ch_module.CHURCH_SOLDIERS)
        ch_module.enemy.hp = ch_module.enemy.maxhp
        ch_module.enemy.sp = ch_module.enemy.maxsp
        ch_module.playerturn = 3
        ch_module.enemyturn  = 3
        battle().start_battle()

    # ------------------------------------------------------------------
    # зоны и события
    # ------------------------------------------------------------------
    def camera_zone(self):
        character = ch_module.character
        self.zone = "camera_zone"
        self.quest_rock = False
        self._offer_save()
        print("*Вы просыпаетесь в закрытой камере.*")
        print("*Единственное, что можно сделать — двигаться вперёд.*")
        while True:
            print("\n(I — инвентарь, S — статистика, E — экипировка.)")
            print("1. Пройти к двери.")
            print("2. Оглядеться вокруг.")
            choice = input("Выберите действие: ").strip().lower()
            if choice in ("1", "пройти к двери", "дверь"):
                if self.quest_rock:
                    print("*Вы разбиваете замок камнем. Выходите из камеры...*")
                    print("*Внезапно перед вами появляется лев!*")
                    character.inventory.remove("Камень")
                    ch_module.tutorial_battle_state = True
                    return
                else:
                    print("*Дверь заперта на замок.*")
            elif choice in ("2", "оглядеться", "осмотреться"):
                if not self.quest_rock:
                    character.inventory.append("Камень")
                    print("*Вы заметили камень на полу.*")
                    print("<<Камень добавлен в инвентарь!>>")
                    self.quest_rock = True
                else:
                    print("*Тут больше ничего нет.*")
            elif choice in ("s", "статистика"):
                self._print_stats()
            elif choice in ("i", "инвентарь"):
                self._show_inventory()
            elif choice in ("e", "экипировка", "оружие"):
                self._equip_weapon()
            else:
                print("Неверное действие.")

    def corridor_zone(self):
        character = ch_module.character
        self.zone = "corridor_zone"
        self._offer_save()
        print("*Вы продолжаете путь по коридору...*")
        print("*На стенах — странные символы и синие огоньки.*")
        while True:
            print("\n(I — инвентарь, S — статистика, E — экипировка.)")
            print("1. Оглядеться вокруг.")
            print("2. Идти дальше по коридору.")
            print("3. Осмотреть льва.")
            choice = input("Выберите действие: ").strip().lower()
            if choice in ("1", "оглядеться"):
                print("*Коридор уходит за угол. Синие огоньки мерцают на стенах.*")
            elif choice in ("2", "идти дальше", "идти"):
                self.old_man()
                break
            elif choice in ("3", "осмотреть льва", "лев"):
                if self.lion_soul:
                    print("*Вы прикоснулись ко льву — в руке оказалось тепло и 3 души.*")
                    print("<<+3 душ>>")
                    character.souls += 3
                    self.lion_soul = False
                else:
                    print("*Тело льва холодное. Нечего брать.*")
            elif choice in ("s", "статистика"):
                self._print_stats()
            elif choice in ("i", "инвентарь"):
                self._show_inventory()
            elif choice in ("e", "экипировка", "оружие"):
                self._equip_weapon()
            else:
                print("Неверное действие.")

    def old_man(self):
        """Первый визит Айвора — только хлеб."""
        self.zone = "old_man"
        self.aivor_visits = 1
        print("*Из тени появляется старик в плаще.*")
        print("'О, давно я не видел здесь живых...'")
        print("'Меня зовут Айвор. Местный торговец. Душонки есть?'")
        print("'Вижу, вы немного вымотались... Вот мой товар.'")
        self.store()

    def river_zone(self):
        character = ch_module.character
        self.zone = "river_zone"
        print("'Спасибо вам... Копите души, ещё увидимся.'")
        print("*Вы идёте дальше и выходите к огромной реке.*")
        print("*Слева — мост с огромным монстром. Справа — ярус с лодками. Впереди — дыра в полу.*")
        while True:
            print("\n(I — инвентарь, S — статистика, E — экипировка.)")
            print("1. Подойти к мосту.")
            print("2. Подойти к ярусу с лодками.")
            print("3. Осмотреть дыру.")
            print("4. Подойти к скоплению монстров.")
            choice = input("Выберите действие: ").strip().lower()
            if choice in ("1", "мост", "подойти к мосту"):
                if ch_module.monster_on_bridge:
                    print("*На мосту сидит грустный огромный монстр.*")
                    print("'Почему я такой страшный... Никто со мной не дружит...'")
                    print("1. Поговорить.   2. Уйти.")
                    c2 = input("> ").strip()
                    if c2 in ("1", "поговорить"):
                        print("'Черепаха сказала, что я только мешаюсь...'")
                        if ch_module.quest_monster_bridge_completed:
                            print("'А... она сказала что это не моя вина?'")
                            print("'Спасибо, человек... Я пойду поговорю с ней.'")
                            print("*Монстр уходит, освобождая мост.*")
                            ch_module.monster_on_bridge = False
                else:
                    print("*Мост свободен. Вы переходите.*")
                    self.bridge_zone()
                    break
                self._maybe_random_encounter_river(0.5)
            elif choice in ("2", "ярус", "лодки", "подойти к ярусу"):
                print("*Лодочники в мантиях молчат.*")
                print("'Пропуск есть? — протягивает руку один из них.'")
                if "pass" in character.inventory:
                    print("*Вы показываете пропуск. Лодочник кивает.*")
                    self.to_the_maze()
                    return
                else:
                    print("'Пропуска нет — не переплывёшь.'")
                self._maybe_random_encounter_river(0.5)
            elif choice in ("3", "дыра", "осмотреть дыру"):
                print("*Вода уходит вниз в темноту... Странно.*")
                self._maybe_random_encounter_river(0.5)
            elif choice in ("4", "монстры", "скопление"):
                if not ch_module.quest_monster_bridge_completed:
                    print("*Ящерица разговаривает с черепахой...*")
                    print("'Теперь когда недоумок ушёл — полакомлюсь!'")
                    print("*Ящерица бросается на вас!*")
                    ch_module.enemy    = ch_module.enemy_placeholder1
                    ch_module.enemy.hp = ch_module.enemy.maxhp
                    ch_module.enemy.sp = ch_module.enemy.maxsp
                    ch_module.playerturn = 3
                    ch_module.enemyturn  = 3
                    battle().start_lizard_battle()
                    if character.hp > 0:
                        print("*После победы великан подходит к вам.*")
                        print("'Черепаха призналась — это была не его вина.'")
                        ch_module.quest_monster_bridge_completed = True
                else:
                    print("*Тут уже никого нет.*")
            elif choice in ("s", "статистика"):
                self._print_stats()
                self._maybe_random_encounter_river(0.5)
            elif choice in ("i", "инвентарь"):
                self._show_inventory()
                self._maybe_random_encounter_river(0.5)
            elif choice in ("e", "экипировка", "оружие"):
                self._equip_weapon()
                self._maybe_random_encounter_river(0.5)
            else:
                print("Неверное действие.")
                self._maybe_random_encounter_river(0.5)

    def bridge_zone(self):
        character = ch_module.character
        self.zone = "bridge_zone"
        self._offer_save()
        print("*За мостом — золотая коробка в земле и усталая душа.*")
        while True:
            print("\n(I — инвентарь, S — статистика, E — экипировка.)")
            print("1. Вернуться назад.")
            print("2. Откопать коробку (нужна СИЛ ≥ 3).")
            print("3. Поговорить с душой.")
            choice = input("Выберите действие: ").strip().lower()
            if choice in ("1", "назад", "вернуться"):
                self.river_zone()
                break
            elif choice in ("2", "коробка", "откопать"):
                if character.get_effective_stat("СИЛ") < 3:
                    print("*Сил не хватает. Нужна СИЛ ≥ 3.*")
                elif "mace" in character.inventory or character.equipped_weapon == "mace":
                    print("*Вы уже взяли булаву.*")
                else:
                    print("*Вы достаёте золотую коробку. Внутри — Булава!*")
                    print("<<Булава добавлена в инвентарь!>>")
                    character.inventory.append("mace")
            elif choice in ("3", "душа", "поговорить"):
                if "pass" in character.inventory:
                    print("'...У тебя уже есть пропуск.'")
                else:
                    print("'Мой друг опаздывает, а пропуск скоро просрочится...'")
                    print("'Держи. Всё равно мне некуда спешить.'")
                    print("<<Пропуск добавлен в инвентарь!>>")
                    character.inventory.append("pass")
            elif choice in ("s", "статистика"):
                self._print_stats()
            elif choice in ("i", "инвентарь"):
                self._show_inventory()
            elif choice in ("e", "экипировка", "оружие"):
                self._equip_weapon()
            else:
                print("Неверное действие.")

    def to_the_maze(self):
        """Second Aivor visit + leopard fight + maze entry."""
        character = ch_module.character
        self.zone = "before_maze_zone"
        self._offer_save()
        print("'Подожди!' *Великан и черепаха догоняют вас.*")
        print("'Спасибо тебе, человек!'")
        print("'О! Вот тебе награда!' *Великан кладёт в вашу руку жёлтый камень.*")
        print("<<Камень: Астрапино добавлен в инвентарь!>>")
        character.inventory.append("astrapino_stone")
        print("*Вы садитесь в лодку и отплываете...*")
        print("*Лодка проваливается в дыру, но медленно опускается вниз.*")
        print("'Ты мне напоминаешь одного... Геласия.' — говорит лодочник.")
        print("'Он в землях за лабиринтом Минотавра. Высадить тебя там?'")
        print("*Вы киваете.*")
        print("*Берег. Вокруг кости и редкая трава.*")
        print("'Дальше ты сам.'")

        # Second Aivor visit
        self.aivor_visits = 2
        print("\n*У входа в поле — знакомый силует. Айвор.*")
        print("'О, мы снова встретились! Ассортимент у меня обновился.'")
        self.store()

        while True:
            print("\n(I — инвентарь, S — статистика, E — экипировка.)")
            print("*Перед вами саванна с костями. Вдали — заброшенный храм.*")
            print("1. Пойти вдоль реки.")
            print("2. Пойти к храму.")
            choice = input("Выберите действие: ").strip().lower()
            if choice in ("1", "вдоль реки", "вдоль"):
                req = 5
                print("*Впереди — золотая коробка за рекой. Прыгать по камням... нужна ТОЧ ≥ 5.*")
                if character.get_effective_stat("ТОЧ") < req:
                    print("*Вы поскользнулись на первом камне и еле добрались назад.*")
                elif "dagger" in character.inventory or character.equipped_weapon == "dagger":
                    print("*Вы уже взяли кинжал.*")
                else:
                    print("*Вы легко перепрыгнули. В коробке — Кинжал!*")
                    print("<<Кинжал добавлен в инвентарь!>>")
                    character.inventory.append("dagger")
            elif choice in ("2", "храм", "к храму"):
                print("*Из тени выпрыгивают два леопарда!*")
                battle().start_leopard_duo_battle()
                break
            elif choice in ("s", "статистика"):
                self._print_stats()
            elif choice in ("i", "инвентарь"):
                self._show_inventory()
            elif choice in ("e", "экипировка", "оружие"):
                self._equip_weapon()
            else:
                print("Неверное действие.")
        self.maze_zone()

    def maze_zone(self):
        character = ch_module.character
        self.zone = "maze_zone"
        self._offer_save()
        print("*Перед вами вырастает вход в каменный лабиринт.*")
        print("*В лабиринт только один путь: Л Л Л П П.*")
        print("*Неправильный поворот — и вы вернётесь к началу. А Минотавр уже ждёт...*")
        print()

        # Secret path: ЛЛЛЛЛЛ -> chest
        SECRET_PATH = ["л", "л", "л", "л", "л"]
        CORRECT_PATH = ["л", "л", "л", "п", "п"]
        step_index   = 0
        secret_index = 0

        while True:
            print(f"\n(Шаг {step_index + 1}/5)  Развилка.")
            print("(I — инвентарь, S — статистика, E — экипировка.)")
            print("1. Налево (Л).")
            print("2. Направо (П).")
            print("3. Вернуться к входу.")
            choice = input("Куда?: ").strip().lower()

            if choice in ("s", "статистика"):
                self._print_stats(); continue
            if choice in ("i", "инвентарь"):
                self._show_inventory(); continue
            if choice in ("e", "экипировка", "оружие"):
                self._equip_weapon(); continue
            if choice in ("3", "вернуться", "назад"):
                print("*Вы возвращаетесь к входу.*")
                step_index = 0; secret_index = 0
                continue

            if choice in ("1", "налево", "лево", "л"):
                step = "л"
            elif choice in ("2", "направо", "право", "п"):
                step = "п"
            else:
                print("Неверный выбор."); continue

            # Check secret path ЛЛЛЛЛЛ
            if step == "л":
                secret_index += 1
                if secret_index == len(SECRET_PATH):
                    print("\n*Тупик... Но на полу — сундук!*")
                    print("*Внутри: Камень: Фотиямано и Камень: Череполом!*")
                    print("<<Камни добавлены в инвентарь!>>")
                    character.inventory.append("fotiamano_stone")
                    character.inventory.append("cherepol_stone")
                    print("*Вы возвращаетесь к входу.*")
                    step_index = 0; secret_index = 0
                    continue
            else:
                secret_index = 0

            # Check correct path
            if step == CORRECT_PATH[step_index]:
                step_index += 1
                print("*Вы осторожно идёте дальше...*")
                if step_index == len(CORRECT_PATH):
                    print("\n*Впереди свет — выход!*")
                    print("*Вы выбираетесь из лабиринта.*")
                    break
            else:
                # Wrong turn — minotaur!
                print("*Что-то не так... Вы снова у входа.*")
                print("*Позади — тяжёлое дыхание!*")
                battle().start_minotaur_battle()
                if character.hp <= 0:
                    return
                step_index = 0; secret_index = 0

        self.medusa_zone()

    def medusa_zone(self):
        character = ch_module.character
        self.zone = "medusa_zone"
        self._offer_save()
        print("*За лабиринтом — люк. Вы спускаетесь вниз.*")
        print("*Серое небо, маленький дождь, разрушенные здания.*")
        print("*В одном из зданий — золотая коробка под потолком. Нужна УДЧ ≥ 6.*")
        if character.get_effective_stat("УДЧ") >= 6:
            print("*Камень попал в коробку. Внутри — Катана!*")
            print("<<Катана добавлена в инвентарь!>>")
            character.inventory.append("katana")
        else:
            print("*Камень летит обратно вам в лоб. Не повезло.*")
        print("*Шорох сзади! Медуза Горгона — с завязанными глазами.*")
        print("'Расслабься... Я не причиню зла. Ты за Геласием?'")
        print("'Предлагаю взаимную помощь. Ты мне — Oko Коя, я тебе — дорогу к Геласию.'")
        character.inventory.append("gorgon_head")
        print("*Медуза отдаёт вам свою голову.*")
        print("<<Голова Медузы добавлена в инвентарь!>>")

        # Third Aivor visit
        self.aivor_visits = 3
        print("\n*По пути к титану вы замечаете знакомого старика.*")
        print("'В третий раз встречаемся... Теперь у меня всё есть.'")
        print("'Покупай смело — больше мы не увидимся.'")
        self.store()

        print("\n*Медуза ведёт вас к Титану Кою...*")
        print("*Земля дрожит...*")
        battle().start_titan_koi_battle()
        if ch_module.character.hp > 0:
            self.zone = "church_zone"
            self.gelasi_church()

    def gelasi_church(self):
        character = ch_module.character
        self.zone = "church_zone"
        commander_defeated = False
        key_obtained       = False

        print("'Титан повержен... Поднеси мою голову к его глазу.'")
        print("*Вспышка. Голова Медузы падает на землю.*")
        print("'Я свободна от проклятия! Спасибо, человек.'")
        print("*Медуза ведёт вас к горам на севере... и останавливается у подножья.*")
        print("*Храм впереди весь в черепах.*")
        print("'Дальше ты сам.' *Она обнимает вас и уходит, плача от счастья.*")
        self._offer_save()
        print("*Во дворе храма — приспешники. Ворота заперты.*")
        print("'Ключ у командира!'")

        while True:
            print("\n(I — инвентарь, S — статистика, E — экипировка.)")
            if not commander_defeated:
                print("1. Осмотреться.   2. Найти командира.")
            elif not key_obtained:
                print("1. Осмотреться.   2. Забрать ключ.   3. Ворота.")
            else:
                print("1. Осмотреться.   2. Ворота.")
            choice = input("Выберите действие: ").strip().lower()

            if choice in ("s", "статистика"):
                self._print_stats()
                self._maybe_random_encounter_church(0.2)
            elif choice in ("i", "инвентарь"):
                self._show_inventory()
                self._maybe_random_encounter_church(0.2)
            elif choice in ("e", "экипировка", "оружие"):
                self._equip_weapon()
                self._maybe_random_encounter_church(0.2)
            elif choice in ("1", "осмотреться"):
                print("*Чёрный камень. Везде черепа.*")
                if not commander_defeated:
                    print("*Где-то слышен командный голос.*")
                self._maybe_random_encounter_church(0.2)
            elif not commander_defeated and choice in ("2", "найти командира", "командир"):
                print("*Широкоплечий мужчина в тёмных доспехах замечает вас.*")
                print("'Убить его!'")
                ch_module.enemy    = ch_module.commander
                ch_module.enemy.hp = ch_module.enemy.maxhp
                ch_module.enemy.sp = ch_module.enemy.maxsp
                ch_module.playerturn = 3
                ch_module.enemyturn  = 3
                battle().start_battle()
                if character.hp <= 0:
                    return
                commander_defeated = True
                print("*Командир падает.*")
                self._maybe_random_encounter_church(0.2)
            elif commander_defeated and not key_obtained and choice in ("2", "забрать ключ", "ключ"):
                print("*На поясе командира — тяжёлый железный ключ.*")
                print("<<Ключ от ворот добавлен в инвентарь!>>")
                character.inventory.append("gate_key")
                key_obtained = True
                self._maybe_random_encounter_church(0.2)
            elif commander_defeated and choice in (
                "2" if key_obtained else "3",
                "ворота", "войти"
            ):
                if not key_obtained:
                    print("*Ворота заперты. Нужен ключ.*")
                    self._maybe_random_encounter_church(0.2)
                else:
                    print("*Ворота открываются.*")
                    break
            else:
                print("Неверное действие.")
                self._maybe_random_encounter_church(0.2)

        # Ambush + monologue + fusion battle
        print("\n*Тёмный зал. Факелы. Свист рассекаемого воздуха — вы едва уклоняетесь!*")
        print("'Ловко.' *Из тени — женщина.* 'Я — Арейя.'")
        print("'Геласий знал, что ты придёшь. Но ты дошёл... Значит, ты тот, о ком он говорил.'")
        print("*Арейя опускает оружие.*")
        print("\n'Достаточно, Арейя.' *Из тьмы выходит высокий мужчина.*")
        print("'...Ты пришёл. Я знал это с момента, как ты убил Коя.'")
        print("'Я не враг тебе. Но ты разрушил всё, что я строил годами.'")
        print("'Тартар умирает. Всё, что я делал — ради спасения этого места.'")
        print("'Теперь у меня один путь. Арейя...' *Он протягивает ей руку.* '...Прости меня.'")
        print("\n'Я знала, что ты скажешь именно это.' *Она берёт его руку.*")
        print("*Вспышка. Они сливаются в единое существо.*")
        print("*Их голоса в унисон:* 'Прости нас. Это единственный способ.'")
        battle().start_gela_arei_battle()

    # ------------------------------------------------------------------
    # последний бой полностью заксриптован
    # ------------------------------------------------------------------
    def Gelasi_fleeing(self):
        print("\n*Вы наносите фатальный удар, но...!*")
        print("*Арейя отсоединяется от его души — принимает удар на себя.*")
        print("*Вы бьётесь об стену. Арейя падает рядом.*")
        print("*Геласий тяжело дышит...*")
        print("'Арейя... Ты спасла меня...'")
        print("*Арейя кричит:* 'Пока он лежит — помоги!'")
        print("*Но Геласий встаёт и бежит!*")
        print("'Геласий! Вернись!' *Арейя кричит вслед, но он не останавливается.*")
        print("*Вы встаёте, чувствуя боль. Нога ранена.*")
        print("'ТЫ СВОЛОЧЬ!' *Арейя кричит в темноту.*")
        print("*Вы замечаете его силуэт — он поднимается на верхние этажи.*")
        print("*Вы бежите за ним. Единственная дорога — на крышу.*")
        print("*Крыша. Тишина. Никого...?*")
        print("*Боль в плече! Геласий, задыхаясь, вонзает кинжал.*")
        print("'Получай!'")
        print("*Вы вырываете кинжал.*")
        print("'Ну что, Син?! *Геласий поднимает кулаки.* Один последний раз!'")
        input("\n[Нажмите Enter, чтобы начать финальный бой...]\n")
        from battle import scripted_final_battle
        scripted_final_battle().run()
        self.end()

    # ------------------------------------------------------------------
    # концовка
    # ------------------------------------------------------------------
    def end(self):
        character = ch_module.character
        self.zone = "end"
        print("\n" + "═" * 50)
        print("*Геласий лежит на камне. Глаза в небо. Вы над ним.*")
        input("[Enter]\n")
        print("'Как...' *Он с трудом дышит.* '...Ты победил.'")
        print("'...Я больше не могу. Сдаюсь.'")
        print("*Вы поворачиваетесь и хромаете вниз.*")
        print("*В зале Арейя ждёт вас. Она смотрит на свою рану.*")
        print("'Ты победил его...' *Тихо.* 'Кажется, мне не нужно было жертвовать собой...'")
        print("*Она падает. Вы опускаетесь рядом.*")
        print("'Пожалуйста... Не дай мне умереть...'")
        print("*Вы обещаете. Поднимаете её на руки.*")
        print("*Медуза! Она сможет помочь.*")
        print("*Вы несёте Арейю к Медузе. Та готовит зелье.*")
        print("'Дай ей это...' *После нескольких минут Арейя открывает глаза.*")
        print("'Спасибо тебе... Ты спас меня.'")
        print("'Покажи мне выход из Тартара...' *Вы говорите.*")
        print("*Арейя указывает дорогу. Вы прощаетесь с Медузой.*")
        print("*Выход. Вспышка.*")
        print("'Хей! *Аид смеётся.* Ты справился! Один, без Арейи?'")
        print("'Ну что ж... Мило. Геласия не вернул, но...'")
        print("'О! Знаешь что — вот твой амулет. Уходи с ним.'")
        input("[Enter]\n")

        # NG+ offer
        print("─" * 50)
        print("Хотите сохранить амулет для Новой Игры+?")
        print("(Ваши характеристики будут перенесены в следующую игру.)")
        ans = input("(y/n): ").strip().lower()
        if ans in ("y", "yes", "д", "да"):
            ng_data = {
                "stats": character.stats.copy(),
                "name":  character.name,
            }
            try:
                with open(NG_PLUS_FILE, "w", encoding="utf-8") as f:
                    json.dump(ng_data, f, ensure_ascii=False, indent=2)
                print("*Амулет сохранён. В главном меню выберите «Новая игра+».*")
            except Exception as e:
                print(f"Не удалось сохранить амулет: {e}")
        print("\nСпасибо за игру. До новых встреч!")


# тут меню и мне лень комменты джелать-----------------------
def main_menu():
    global game
    while True:
        print(MENU_ART)
        choice = input("Выберите действие: ").strip().lower()

        if choice in ("1", "начать игру сначала", "начать"):
            game = Game()
            game.run()

        elif choice in ("2", "загрузить игру", "загрузить"):
            game = Game()
            loaded = game.load_from_slot()
            if not loaded:
                # User pressed 0 in load menu — go back to main menu
                continue

        elif choice in ("3", "новая игра+", "нг+", "ng+"):
            try:
                with open(NG_PLUS_FILE, "r", encoding="utf-8") as f:
                    ng_data = json.load(f)
                ng_stats = ng_data.get("stats")
                print(f"*Амулет найден. Характеристики: {ng_stats}*")
                game = Game(ng_plus_stats=ng_stats)
                game.run()
            except FileNotFoundError:
                print("Амулет не найден. Сначала пройдите игру и сохраните амулет в конце.")
                continue
            except Exception as e:
                print(f"Ошибка при загрузке амулета: {e}")
                continue

        elif choice in ("4", "выйти из игры", "выйти"):
            print("Вы вышли из игры.")
            break

        else:
            print("Неверное действие.")


if __name__ == "__main__":
    main_menu()
